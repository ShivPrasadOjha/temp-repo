package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentStatusCheckResponse;

public class ResponseStatusCheckIMPS implements PaymentStatusCheckResponse {

    @JsonProperty("CheckStatusCode")
    private String checkStatusCode;
    @JsonProperty("CheckStatusMessage")
    private String checkStatusMessage;
    @JsonProperty("ActCode")
    private String actCode;
    @JsonProperty("Response")
    private String response;
    @JsonProperty("BankRRN")
    private String bankRRN;
    @JsonProperty("BeneName")
    private String beneName;
    @JsonProperty("TranRefNo")
    private String tranRefNo;
    @JsonProperty("PaymentRef")
    private String paymentRef;
    @JsonProperty("TranDateTime")
    private String tranDateTime;
    @JsonProperty("Amount")
    private String amount;
    @JsonProperty("BeneMMID")
    private String beneMMID;
    @JsonProperty("BeneMobile")
    private String beneMobile;
    @JsonProperty("BeneAccNo")
    private String beneAccNo;
    @JsonProperty("BeneIFSC")
    private String beneIFSC;
    @JsonProperty("RemMobile")
    private String remMobile;
    @JsonProperty("RemName")
    private String remName;
    @JsonProperty("RetailerCode")
    private String retailerCode;
    @JsonIgnore
    private int responseCode;
    @JsonIgnore
    private String responseBody;

    public ResponseStatusCheckIMPS() {
        // TO-DO
    }

    public ResponseStatusCheckIMPS(String checkStatusCode, String checkStatusMessage, String actCode, String response, String bankRRN,
                                   String beneName, String tranRefNo, String paymentRef, String tranDateTime, String amount, String beneMMID,
                                   String beneMobile, String beneAccNo, String beneIFSC, String remMobile, String remName,
                                   String retailerCode, int responseCode, String responseBody) {
        this.checkStatusCode = checkStatusCode;
        this.checkStatusMessage = checkStatusMessage;
        this.actCode = actCode;
        this.response = response;
        this.bankRRN = bankRRN;
        this.beneName = beneName;
        this.tranRefNo = tranRefNo;
        this.paymentRef = paymentRef;
        this.tranDateTime = tranDateTime;
        this.amount = amount;
        this.beneMMID = beneMMID;
        this.beneMobile = beneMobile;
        this.beneAccNo = beneAccNo;
        this.beneIFSC = beneIFSC;
        this.remMobile = remMobile;
        this.remName = remName;
        this.retailerCode = retailerCode;
        this.responseCode = responseCode;
        this.responseBody = responseBody;
    }

    public String getCheckStatusCode() {
        return checkStatusCode;
    }

    public void setCheckStatusCode(String checkStatusCode) {
        this.checkStatusCode = checkStatusCode;
    }

    public String getCheckStatusMessage() {
        return checkStatusMessage;
    }

    public void setCheckStatusMessage(String checkStatusMessage) {
        this.checkStatusMessage = checkStatusMessage;
    }

    public String getActCode() {
        return actCode;
    }

    public void setActCode(String actCode) {
        this.actCode = actCode;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getBankRRN() {
        return bankRRN;
    }

    public void setBankRRN(String bankRRN) {
        this.bankRRN = bankRRN;
    }

    public String getBeneName() {
        return beneName;
    }

    public void setBeneName(String beneName) {
        this.beneName = beneName;
    }

    public String getTranRefNo() {
        return tranRefNo;
    }

    public void setTranRefNo(String tranRefNo) {
        this.tranRefNo = tranRefNo;
    }

    public String getPaymentRef() {
        return paymentRef;
    }

    public void setPaymentRef(String paymentRef) {
        this.paymentRef = paymentRef;
    }

    public String getTranDateTime() {
        return tranDateTime;
    }

    public void setTranDateTime(String tranDateTime) {
        this.tranDateTime = tranDateTime;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getBeneMMID() {
        return beneMMID;
    }

    public void setBeneMMID(String beneMMID) {
        this.beneMMID = beneMMID;
    }

    public String getBeneMobile() {
        return beneMobile;
    }

    public void setBeneMobile(String beneMobile) {
        this.beneMobile = beneMobile;
    }

    public String getBeneAccNo() {
        return beneAccNo;
    }

    public void setBeneAccNo(String beneAccNo) {
        this.beneAccNo = beneAccNo;
    }

    public String getBeneIFSC() {
        return beneIFSC;
    }

    public void setBeneIFSC(String beneIFSC) {
        this.beneIFSC = beneIFSC;
    }

    public String getRemMobile() {
        return remMobile;
    }

    public void setRemMobile(String remMobile) {
        this.remMobile = remMobile;
    }

    public String getRemName() {
        return remName;
    }

    public void setRemName(String remName) {
        this.remName = remName;
    }

    public String getRetailerCode() {
        return retailerCode;
    }

    public void setRetailerCode(String retailerCode) {
        this.retailerCode = retailerCode;
    }

    @Override
    public int getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    @Override
    public String getResponseBody() {
        return responseBody;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }
}