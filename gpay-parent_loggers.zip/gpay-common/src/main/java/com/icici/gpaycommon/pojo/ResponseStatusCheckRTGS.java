package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentStatusCheckResponse;

public class ResponseStatusCheckRTGS implements PaymentStatusCheckResponse {

    @JsonProperty("STATUS")
    private String status;
    @JsonProperty("URN")
    private String urn;
    @JsonProperty("UNIQUEID")
    private String uniqueid;
    @JsonProperty("UTRNUMBER")
    private String utrnumber;
    @JsonProperty("RESPONSE")
    private String response;
    @JsonIgnore
    private int responseCode;
    @JsonIgnore
    private String responseBody;

    /**
     * No args constructor for use in serialization
     *
     */
    public ResponseStatusCheckRTGS() {
    }

    /**
     *
     * @param urn
     * @param utrnumber
     * @param response
     * @param uniqueid
     * @param status
     */
    public ResponseStatusCheckRTGS(String status, String urn, String uniqueid, String utrnumber, String response) {
        super();
        this.status = status;
        this.urn = urn;
        this.uniqueid = uniqueid;
        this.utrnumber = utrnumber;
        this.response = response;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUrn() {
        return urn;
    }

    public void setUrn(String urn) {
        this.urn = urn;
    }

    public String getUniqueid() {
        return uniqueid;
    }

    public void setUniqueid(String uniqueid) {
        this.uniqueid = uniqueid;
    }

    public String getUtrnumber() {
        return utrnumber;
    }

    public void setUtrnumber(String utrnumber) {
        this.utrnumber = utrnumber;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }

    @Override
    public int getResponseCode() {
        return this.responseCode;
    }

    @Override
    public String getResponseBody() {
        return this.responseBody;
    }

}