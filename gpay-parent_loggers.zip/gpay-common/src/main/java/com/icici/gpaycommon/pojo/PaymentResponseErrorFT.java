package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentResponse;


public class PaymentResponseErrorFT implements PaymentResponse {

    @JsonProperty("MESSAGE")
    private String message;
    @JsonProperty("ERRORCODE")
    private String errorcode;
    @JsonProperty("RESPONSECODE")
    private String responsecode;
    @JsonProperty("STATUS")
    private String status;
    @JsonProperty("RESPONSE")
    private String response;
    @JsonIgnore
    private int responseCode;
    @JsonIgnore
    private String responseBody;
    /**
     * No args constructor for use in serialization
     *
     */
    public PaymentResponseErrorFT(){
    }

    /**
     *
     * @param responsecode
     * @param response
     * @param message
     * @param errorcode
     * @param status
     */
    public PaymentResponseErrorFT(String message, String errorcode, String responsecode, String status, String response) {
        super();
        this.message = message;
        this.errorcode = errorcode;
        this.responsecode = responsecode;
        this.status = status;
        this.response = response;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getErrorcode() {
        return errorcode;
    }

    public void setErrorcode(String errorcode) {
        this.errorcode = errorcode;
    }

    public String getResponsecode() {
        return responsecode;
    }

    public void setResponsecode(String responsecode) {
        this.responsecode = responsecode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    @Override
    public int getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    @Override
    public String getResponseBody() {
        return responseBody;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }

}