package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentStatusCheckRequest;

public class RequestStatusCheckIMPS implements PaymentStatusCheckRequest {

    @JsonProperty("transRefNo")
    private String transRefNo;
    @JsonProperty("date")
    private String date;
    @JsonProperty("recon360")
    private String recon360;
    @JsonProperty("passCode")
    private String passCode;
    @JsonProperty("bcID")
    private String bcID;

    /**
     * No args constructor for use in serialization
     *
     */
    public RequestStatusCheckIMPS() {
    }

    /**
     *
     * @param date
     * @param bcID
     * @param recon360
     * @param transRefNo
     * @param passCode
     */
    public RequestStatusCheckIMPS(String transRefNo, String date, String recon360, String passCode, String bcID) {
        super();
        this.transRefNo = transRefNo;
        this.date = date;
        this.recon360 = recon360;
        this.passCode = passCode;
        this.bcID = bcID;
    }

    public String getTransRefNo() {
        return transRefNo;
    }

    public void setTransRefNo(String transRefNo) {
        this.transRefNo = transRefNo;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getRecon360() {
        return recon360;
    }

    public void setRecon360(String recon360) {
        this.recon360 = recon360;
    }

    public String getPassCode() {
        return passCode;
    }

    public void setPassCode(String passCode) {
        this.passCode = passCode;
    }

    public String getBcID() {
        return bcID;
    }

    public void setBcID(String bcID) {
        this.bcID = bcID;
    }

}