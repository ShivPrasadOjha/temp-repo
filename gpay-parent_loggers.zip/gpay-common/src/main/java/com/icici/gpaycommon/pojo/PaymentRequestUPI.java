package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentRequest;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public class PaymentRequestUPI implements PaymentRequest{

    @JsonProperty("amount")
    private String amount;
    @JsonProperty("txn-type")
    private String txnType;
    @JsonProperty("mobile")
    private String mobile;
    @JsonProperty("payee-va")
    private String payeeVa;
    @JsonProperty("default-debit")
    private String defaultDebit;
    @JsonProperty("mcc")
    private String mcc;
    @JsonProperty("device-id")
    private String deviceId;
    @JsonProperty("account-provider")
    private String accountProvider;
    @JsonProperty("userID")
    private String userId;
    @JsonProperty("bnfId")
    private String bnfId;
    @JsonProperty("aggrID")
    private String aggrId;
    @JsonProperty("seq-no")
    private String seqNo;
    @JsonProperty("urn")
    private String urn;
    @JsonProperty("merchant-type")
    private String merchantType;
    @JsonProperty("crpID")
    private String crpId;
    @JsonProperty("channel-code")
    private String channelCode;
    @JsonProperty("pre-approved")
    private String preApproved;
    @JsonProperty("use-default-acc")
    private String useDefaultAcc;
    @JsonProperty("profile-id")
    private String profileId;
    @JsonProperty("default-credit")
    private String defaultCredit;
    @JsonProperty("payer-va")
    private String payerVa;
    @JsonProperty("remarks")
    private String remarks;
    @JsonProperty("aggrName")
    private String aggrName;
    @JsonProperty("payee-mcc")
    private String payeeMcc;
    @JsonProperty("vpa")
    private String vpa;
    @JsonProperty("payee-name")
    private String payeeName;
    @JsonProperty("account-number")
    private String accountNumber;
    @JsonProperty("account-type")
    private String accountType;

    @JsonProperty("global-address-type")
    private String globalAddressType;

    @JsonProperty("payee-account")
    private String payeeAccount;

    @JsonProperty("payee-IFSC")
    private String payeeIfsc;
    @JsonProperty("initiation-mode")
    private String initiationMode;
    @JsonProperty("purpose")
    private String purpose;
    @JsonProperty("ref-id")
    private String refId;
    @JsonProperty("currency")
    private String currency;

    public PaymentRequestUPI() {
        super();
    }

    public PaymentRequestUPI(String amount, String txnType, String mobile, String payeeVa, String defaultDebit, String mcc, String deviceId,
                             String accountProvider, String userId, String bnfId, String aggrId, String seqNo, String urn,
                             String merchantType, String crpId, String channelCode, String preApproved, String useDefaultAcc,
                             String profileId, String defaultCredit, String payerVa, String remarks, String aggrName, String payeeMcc,
                             String vpa, String payeeName, String accountNumber, String accountType, String globalAddressType,
                             String payeeAccount, String payeeIfsc, String initiationMode, String purpose, String refId, String currency) {
        this.amount = amount;
        this.txnType = txnType;
        this.mobile = mobile;
        this.payeeVa = payeeVa;
        this.defaultDebit = defaultDebit;
        this.mcc = mcc;
        this.deviceId = deviceId;
        this.accountProvider = accountProvider;
        this.userId = userId;
        this.bnfId = bnfId;
        this.aggrId = aggrId;
        this.seqNo = seqNo;
        this.urn = urn;
        this.merchantType = merchantType;
        this.crpId = crpId;
        this.channelCode = channelCode;
        this.preApproved = preApproved;
        this.useDefaultAcc = useDefaultAcc;
        this.profileId = profileId;
        this.defaultCredit = defaultCredit;
        this.payerVa = payerVa;
        this.remarks = remarks;
        this.aggrName = aggrName;
        this.payeeMcc = payeeMcc;
        this.vpa = vpa;
        this.payeeName = payeeName;
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.globalAddressType = globalAddressType;
        this.payeeAccount = payeeAccount;
        this.payeeIfsc = payeeIfsc;
        this.initiationMode = initiationMode;
        this.purpose = purpose;
        this.refId = refId;
        this.currency = currency;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getTxnType() {
        return txnType;
    }

    public void setTxnType(String txnType) {
        this.txnType = txnType;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPayeeVa() {
        return payeeVa;
    }

    public void setPayeeVa(String payeeVa) {
        this.payeeVa = payeeVa;
    }

    public String getDefaultDebit() {
        return defaultDebit;
    }

    public void setDefaultDebit(String defaultDebit) {
        this.defaultDebit = defaultDebit;
    }

    public String getMcc() {
        return mcc;
    }

    public void setMcc(String mcc) {
        this.mcc = mcc;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getAccountProvider() {
        return accountProvider;
    }

    public void setAccountProvider(String accountProvider) {
        this.accountProvider = accountProvider;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getBnfId() {
        return bnfId;
    }

    public void setBnfId(String bnfId) {
        this.bnfId = bnfId;
    }

    public String getAggrId() {
        return aggrId;
    }

    public void setAggrId(String aggrId) {
        this.aggrId = aggrId;
    }

    public String getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    public String getUrn() {
        return urn;
    }

    public void setUrn(String urn) {
        this.urn = urn;
    }

    public String getMerchantType() {
        return merchantType;
    }

    public void setMerchantType(String merchantType) {
        this.merchantType = merchantType;
    }

    public String getCrpId() {
        return crpId;
    }

    public void setCrpId(String crpId) {
        this.crpId = crpId;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getPreApproved() {
        return preApproved;
    }

    public void setPreApproved(String preApproved) {
        this.preApproved = preApproved;
    }

    public String getUseDefaultAcc() {
        return useDefaultAcc;
    }

    public void setUseDefaultAcc(String useDefaultAcc) {
        this.useDefaultAcc = useDefaultAcc;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getDefaultCredit() {
        return defaultCredit;
    }

    public void setDefaultCredit(String defaultCredit) {
        this.defaultCredit = defaultCredit;
    }

    public String getPayerVa() {
        return payerVa;
    }

    public void setPayerVa(String payerVa) {
        this.payerVa = payerVa;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getAggrName() {
        return aggrName;
    }

    public void setAggrName(String aggrName) {
        this.aggrName = aggrName;
    }

    public String getPayeeMcc() {
        return payeeMcc;
    }

    public void setPayeeMcc(String payeeMcc) {
        this.payeeMcc = payeeMcc;
    }

    public String getVpa() {
        return vpa;
    }

    public void setVpa(String vpa) {
        this.vpa = vpa;
    }

    public String getPayeeName() {
        return payeeName;
    }

    public void setPayeeName(String payeeName) {
        this.payeeName = payeeName;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getGlobalAddressType() {
        return globalAddressType;
    }

    public void setGlobalAddressType(String globalAddressType) {
        this.globalAddressType = globalAddressType;
    }

    public String getPayeeAccount() {
        return payeeAccount;
    }

    public void setPayeeAccount(String payeeAccount) {
        this.payeeAccount = payeeAccount;
    }

    public String getPayeeIfsc() {
        return payeeIfsc;
    }

    public void setPayeeIfsc(String payeeIfsc) {
        this.payeeIfsc = payeeIfsc;
    }

    public String getInitiationMode() {
        return initiationMode;
    }

    public void setInitiationMode(String initiationMode) {
        this.initiationMode = initiationMode;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /*    @Override
    public PaymentRequestUPI getPaymentRequest() {
        return this;
    }

    @Override
    public void setPaymentRequest(PaymentRequest paymentRequest) {
        // For future use
    }

    @Override
    public void setPaymentRequest(String paymentRequestString) {
        ObjectMapper om = new ObjectMapper();
        try {
            PaymentRequestUPI transactionUPI = om.readValue(paymentRequestString, PaymentRequestUPI.class);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }*/
}