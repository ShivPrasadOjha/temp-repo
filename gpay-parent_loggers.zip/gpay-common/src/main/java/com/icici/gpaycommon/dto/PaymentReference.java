package com.icici.gpaycommon.dto;

import com.icici.gpaycommon.enums.PAYMENT_STATUS;

/**
 * @author aditya_shekhar on 2/23/2024
 */
public class PaymentReference {

    private String settlementId;
    private String transactionId;
    private String refPaymentStatus;

    public PaymentReference(String settlementId, String transactionId, String refPaymentStatus) {
        this.settlementId = settlementId;
        this.transactionId = transactionId;
        this.refPaymentStatus = refPaymentStatus;
    }

    public String getSettlementId() {
        return settlementId;
    }

    public void setSettlementId(String settlementId) {
        this.settlementId = settlementId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getRefPaymentStatus() {
        return refPaymentStatus;
    }

    public void setRefPaymentStatus(String refPaymentStatus) {
        this.refPaymentStatus = refPaymentStatus;
    }
}
