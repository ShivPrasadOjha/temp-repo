package com.icici.gpayprocessor.impl;

import com.icici.gpaycommon.exception.ProcessorException;
import com.icici.gpaycommon.serdes.PaymentSerdes;
import com.icici.gpayprocessor.helper.PropertyHelper;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;

import java.util.Properties;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public abstract class BaseProcessor {
    protected Properties streamsConfiguration = null;
    private Properties props;
    {
        props = PropertyHelper.getInstance().getProperties();
    }

    private String rocksDbStore = props.getProperty("ROCKS_DB_STORE");
    private String bootstrapServers = props.getProperty("BOOTSTRAP_SERVERS");
    private String activeProfile = props.getProperty("spring.profiles.active");

    public BaseProcessor() throws ProcessorException {
        System.setProperty("java.io.tmpdir", rocksDbStore);
        this.streamsConfiguration = new Properties();
        //streamsConfiguration.put(StreamsConfig.APPLICATION_ID_CONFIG, applicationId);
        streamsConfiguration.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        streamsConfiguration.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        streamsConfiguration.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, PaymentSerdes.serde().getClass().getName());
        if(activeProfile.equals("uat")) {
            streamsConfiguration.put("ssl.truststore.location", "/frontoffice/cp.server.truststore.jks");
            streamsConfiguration.put("ssl.truststore.password" ,"changeit");
            streamsConfiguration.put("ssl.keystore.location", "/frontoffice/cp.server.keystore.jks");
            streamsConfiguration.put("ssl.keystore.password" ,"changeit");
            streamsConfiguration.put("security.protocol" ,"SSL");
            streamsConfiguration.put("ssl.client.auth" ,"required");
            streamsConfiguration.put("ssl.enabled.protocols" ,"TLSv1.2,TLSv1.1,TLSv1");
        }
    }

   public abstract Topology build(StreamsBuilder builder);
    public abstract void run();

}
