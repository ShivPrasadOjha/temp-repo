/*
package com.icici.gpayprocessor.paymentswitch;

*/
/**
 * @author aditya_shekhar on 1/31/2024
 *//*

public class PaymentUPI implements Callable<SymbolInfo> {

    private static String referer = "http://www.moneycontrol.com/";
    private static String userAgent = "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:54.0) Gecko/20100101 Firefox/54.0";
    private Long tableRefId;
    private String scripName;
    private String url;
    private String baseUrl;
    private SymbolInfo symbolInfo = null;

    public MoneycontrolSymbolDetailInfo(Long tableRefId, String scripName, String url, String baseUrl) {
        super();
        this.tableRefId = tableRefId;
        this.scripName = scripName;
        this.url = url;
        this.baseUrl = baseUrl;
    }

    public String getScripName() {
        return scripName;
    }

    public String getUrl() {
        return url;
    }

    public SymbolInfo getSymbolInfo() {
        return symbolInfo;
    }

    @Override
    public SymbolInfo call() {
        Document doc = null;
        try {
            doc = Jsoup.connect(url).timeout(600000).userAgent(userAgent).referrer(referer).get();
            String scripCompanyName = doc.select("div.moneyprice_bx > h1.pcstname").text();
            System.out.println(scripName + ":::" + scripCompanyName);
            if (scripCompanyName == null || scripCompanyName.equals("")) {
                symbolInfo = new SymbolInfo(scripName, url, baseUrl);
                symbolInfo.setTableRefId(tableRefId);
                return symbolInfo;
            }
            //String scripInfo = doc.select("#nChrtPrc > div.PB10 > div.FL.gry10").text();
            //System.out.println(doc.select("div.moneyprice_bx"));
            //Elements eeee = doc.select("div.moneyprice_bx > div.clearfix > p.bsns_pcst");
            String scripInfo = doc.select("div.moneyprice_bx > div.clearfix > p.bsns_pcst").text();
            Elements tempElements = doc.getElementsByTag("script");
            String mcCode = null;
            String[] mcCodeArray = url.split("/");
            mcCode = mcCodeArray[mcCodeArray.length-1];
			*/
/*for (Element e1 : tempElements) {
				if(e1.html().contains("load_chart")) {
					mcCode = CommonParser.parseAndPick(e1.html(), "/his/", ".csv");
					if(mcCode!=null) {
						break;
					}
				}
			}*//*

            scripInfo = scripInfo.replaceAll("\\|\\s\\|", "\\|");
            String[] scripData = scripInfo.split("\\|");
            System.out.println("scripInfo:::" + scripInfo);
            SymbolInfo symbolInfo = new SymbolInfo(scripName, scripCompanyName, scripData[0].split(":")[1].trim(),
                    scripData[1].split(":")[1].trim(), scripData[3].split(":")[1].trim(), scripData[4].split(":")[1].trim(),
                    url, tableRefId, baseUrl, mcCode);
			*/
/*symbolInfo.setTableRefId(this.tableRefId);
			symbolInfo.setBaseUrl(this.baseUrl);*//*

            return symbolInfo;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            // e.printStackTrace();
            System.out.println(e.getCause());
            System.out.println("URL::" + url);
            symbolInfo = new SymbolInfo(scripName, url);
            symbolInfo.setTableRefId(tableRefId);
            return symbolInfo;
        }
    }

}*/
