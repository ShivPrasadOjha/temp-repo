package com.icici.gpayscheduler.paymentswitch;

import java.util.concurrent.Callable;

/**
 * @author aditya_shekhar on 1/31/2024
 */

public class PaymentUPI implements Callable<Object> {

    public PaymentUPI() {
        super();
    }

    @Override
    public Object call() {
        return null;
    }

}