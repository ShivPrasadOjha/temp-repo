package com.icici.gpayscheduler.impl.rtgs;

import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.dto.PaymentRetry;
import com.icici.gpaycommon.enums.PAYMENT_STATUS;
import com.icici.gpaycommon.exception.ProcessorException;
import com.icici.gpaycommon.helper.PropertyHelper;
import com.icici.gpaycommon.serdes.PaymentImpsSerdes;
import com.icici.gpaycommon.serdes.PaymentRtgsSerdes;
import com.icici.gpaycommon.serdes.PaymentSerdes;
import com.icici.gpaycommon.topic.KafkaTopics;
import com.icici.gpayscheduler.impl.BaseProcessor;
import com.icici.gpayscheduler.impl.neft.NeftPendingTaskProcessor;
import com.icici.gpayscheduler.joiner.PendingPaymentstJoiner;
import com.icici.gpayscheduler.task.TaskMatrix;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.*;

import java.time.Duration;
import java.util.Date;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author aditya_shekhar on 2/5/2024
 */
public class RtgsPendingTaskProcessor extends BaseProcessor{

    private static final Logger log = LoggerFactory.getLogger(RtgsPendingTaskProcessor.class);
    private Properties props;
    {
        props = PropertyHelper.getInstance().getProperties();
    }

    private String pmtRtgsStatusCheckTempTopic = KafkaTopics.GPAY_PMT_RTGS_STATUS_CHECK_TEMP_TOPIC;
    private String pmtRtgsStatusCheckTopic = KafkaTopics.GPAY_PMT_RTGS_STATUS_CHECK_TOPIC;
    private String pmtRtgsPendingTopic = KafkaTopics.GPAY_PMT_RTGS_PENDING_TOPIC;
    private String pmtPendingParkedTopic = KafkaTopics.GPAY_PMT_PENDING_PARKED_TOPIC;
    private String appID = props.getProperty("GPAY_RTGS_PENDING_TASK_APP");
    private StreamsBuilder builder = null;

    public RtgsPendingTaskProcessor() throws ProcessorException {
        super();
    }

    @Override
    public Topology build(StreamsBuilder builder) {
        builder = new StreamsBuilder();
        //KStream<String, Payment> rtgsPendingStream = builder.stream(pmtRtgsPendingTopic, Consumed.with(Serdes.String(),
        // PaymentRtgsSerdes.serde()));

        KStream<String, Payment> rtgsPendingStream = builder.stream(pmtRtgsPendingTopic, Consumed.with(Serdes.String(),
                        PaymentSerdes.serde()))
                .groupByKey().windowedBy(TimeWindows.of(Duration.ofSeconds(15)))
                .reduce((value1, value2) -> {
                    log.info("{}",value1);
                    return value2;
                })
                .toStream( (windowedKey,value) ->  windowedKey.key());

        rtgsPendingStream.split().branch((key, value) -> {
                    boolean rtgsCutoff = false;
                    if(value.getPaymentRetry()!=null) {
                        if (value.getPaymentRetry().getRetryCount()==0) {
                            PaymentRetry retry = value.getPaymentRetry();
                            retry.setLastRetryDatetime(value.getPaymentRespDateTime()!=null ? value.getPaymentRespDateTime() :
                                    value.getPaymentReqDateTime());
                            value.setPaymentRetry(retry);
                        }
                        rtgsCutoff = TaskMatrix.isRtgsCutoffApplicable(value.getPaymentRetry());
                    }
                    return rtgsCutoff;
                }, Branched.withConsumer((ks) -> {
                    ks.mapValues(v -> {
                        PaymentRetry retry = v.getPaymentRetry();
                        if(retry==null) {
                            retry = new PaymentRetry();
                        }
                        retry.setDequeueDatetime(new Date());
                        retry.setRetryCount(retry.getRetryCount() + 1);
                        v.setPaymentRetry(retry);
                        return v;
                    }).to(pmtRtgsStatusCheckTempTopic, Produced.with(Serdes.String(), PaymentRtgsSerdes.serde()));
                })).branch((key, value) -> {
                    boolean rtgsCutoffFail = false;
                    int retryC = value.getPaymentRetry().getRetryCount();
                    if(value.getPaymentRetry()!=null) {
                        rtgsCutoffFail = !TaskMatrix.isRtgsCutoffApplicable(value.getPaymentRetry())
                                && !TaskMatrix.isRtgsTriesExhausted(value.getPaymentRetry());
                    }
                    return rtgsCutoffFail;
                }, Branched.withConsumer((ks) -> ks.to(pmtRtgsPendingTopic, Produced.with(Serdes.String(), PaymentRtgsSerdes.serde()))))
                .branch((key, value) -> {
                    boolean retriesExhausted = false;
                    if(value.getPaymentRetry()!=null) {
                        retriesExhausted = TaskMatrix.isRtgsTriesExhausted(value.getPaymentRetry());
                    }
                    return retriesExhausted;
                }, Branched.withConsumer((ks) -> {
                    ks.mapValues(v -> {
                        v.setPaymentStatus(PAYMENT_STATUS.PARKED_PENDING);
                        return v;
                    }).to(pmtPendingParkedTopic, Produced.with(Serdes.String(), PaymentRtgsSerdes.serde()));
                }));

        ValueJoiner<Payment, Payment, Payment> pendingJoiner = new PendingPaymentstJoiner();
        KTable<String, Payment> rtgsStatusCheckTempTable = builder.table(pmtRtgsStatusCheckTempTopic, Consumed.with(Serdes.String(),
                PaymentRtgsSerdes.serde()));
        KTable<String, Payment> rtgsStatusCheckTable = builder.table(pmtRtgsStatusCheckTopic, Consumed.with(Serdes.String(),
                PaymentRtgsSerdes.serde()));
        KTable<String, Payment> pendingValidTable = rtgsStatusCheckTempTable.leftJoin(rtgsStatusCheckTable, pendingJoiner);
        pendingValidTable.toStream().filter((k,v) -> v!=null && v.getUuid()!=null)
                .to(pmtRtgsStatusCheckTopic, Produced.with(Serdes.String(), PaymentRtgsSerdes.serde()));

        Topology topology = builder.build();
        return topology;
    }

    @Override
    public void run() {
        Topology topology = build(builder);
        super.streamsConfiguration.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, PaymentRtgsSerdes.serde().getClass().getName());
        super.streamsConfiguration.put(StreamsConfig.APPLICATION_ID_CONFIG, appID);
        KafkaStreams streams = new KafkaStreams(topology, super.streamsConfiguration);
        streams.start();
    }

    /*public static void main(String[] args) throws ProcessorException {
        System.out.println("RtgsPendingTaskProcessor starting.....");
        BaseProcessor bp = new RtgsPendingTaskProcessor();
        bp.run();
        System.out.println("RtgsPendingTaskProcessor running now.....");
    }*/
}
