package com.icici.gpayscheduler;

import com.icici.gpaycommon.exception.ProcessorException;
import com.icici.gpayscheduler.impl.BaseProcessor;
import com.icici.gpayscheduler.impl.ft.FtPendingTaskProcessor;
import com.icici.gpayscheduler.impl.ft.FtStatusCheckProcessor;
import com.icici.gpayscheduler.impl.imps.ImpsPendingTaskProcessor;
import com.icici.gpayscheduler.impl.imps.ImpsStatusCheckProcessor;
import com.icici.gpayscheduler.impl.neft.NeftPendingTaskProcessor;
import com.icici.gpayscheduler.impl.neft.NeftStatusCheckProcessor;
import com.icici.gpayscheduler.impl.rtgs.RtgsPendingTaskProcessor;
import com.icici.gpayscheduler.impl.rtgs.RtgsStatusCheckProcessor;
import com.icici.gpayscheduler.impl.upi.UpiPendingTaskProcessor;
import com.icici.gpayscheduler.impl.upi.UpiStatusCheckProcessor;

import java.time.Instant;
import java.util.Date;
import java.util.Optional;
import java.util.Properties;
import java.util.concurrent.Executor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author aditya_shekhar on 2/2/2024
 */
public class SchedulerApp {
    private static final Logger log = LoggerFactory.getLogger(SchedulerApp.class);

    public static void main(String[] args) throws ProcessorException {
        log.info("UpiPendingTaskProcessor starting.....");
        BaseProcessor bp1 = new UpiPendingTaskProcessor();
        bp1.run();
        log.info("UpiPendingTaskProcessor running now.....");
        log.info("UpiStatusCheckProcessor starting.....");
        BaseProcessor bp2 = new UpiStatusCheckProcessor();
        bp2.run();
        log.info("UpiStatusCheckProcessor running now.....");
        log.info("ImpsPendingTaskProcessor starting.....");
        BaseProcessor bp3 = new ImpsPendingTaskProcessor();
        bp3.run();
        log.info("ImpsPendingTaskProcessor running now.....");
        log.info("ImpsStatusCheckProcessor starting.....");
        BaseProcessor bp4 = new ImpsStatusCheckProcessor();
        bp4.run();
        log.info("ImpsStatusCheckProcessor running now.....");
        log.info("NeftPendingTaskProcessor starting.....");
        BaseProcessor bp5 = new NeftPendingTaskProcessor();
        bp5.run();
        log.info("NeftPendingTaskProcessor running now.....");
        log.info("NeftStatusCheckProcessor starting.....");
        BaseProcessor bp6 = new NeftStatusCheckProcessor();
        bp6.run();
        log.info("NeftStatusCheckProcessor running now.....");
        log.info("RtgsPendingTaskProcessor starting.....");
        BaseProcessor bp7 = new RtgsPendingTaskProcessor();
        bp7.run();
        log.info("RtgsPendingTaskProcessor running now.....");
        log.info("RtgsStatusCheckProcessor starting.....");
        BaseProcessor bp8 = new RtgsStatusCheckProcessor();
        bp8.run();
        log.info("RtgsStatusCheckProcessor running now.....");
        log.info("FtPendingTaskProcessor starting.....");
        BaseProcessor bp9 = new FtPendingTaskProcessor();
        bp9.run();
        log.info("FtPendingTaskProcessor running now.....");
        log.info("FtStatusCheckProcessor starting.....");
        BaseProcessor bp10 = new FtStatusCheckProcessor();
        bp10.run();
        log.info("FtStatusCheckProcessor running now....");
    }
}
