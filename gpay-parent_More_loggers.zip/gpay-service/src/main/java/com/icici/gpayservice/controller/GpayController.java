package com.icici.gpayservice.controller;

import com.icici.gpaycommon.api.PaymentSwitch;
import com.icici.gpaycommon.dto.*;
import com.icici.gpaycommon.enums.PAYMENT_STATUS;
import com.icici.gpaycommon.enums.PAYMENT_TYPE;
import com.icici.gpaycommon.exception.ProcessorException;
import com.icici.gpayservice.service.PaymentService;
import com.icici.gpayservice.service.ProducerService;
import io.confluent.ksql.api.client.KsqlObject;
import io.confluent.ksql.api.client.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.*;

/**
 * @author aditya_shekhar on 1/20/2024
 */
@RestController
@RequestMapping("api/v1/gpay/")
public class GpayController{

    private static final Logger log = LoggerFactory.getLogger(GpayController.class);

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private ProducerService producerService;
    private PaymentSwitch paymentSwitch = new PaymentSwitch();

    @GetMapping("/get-transaction-status")
    public TransactionStatistics getStatus(@RequestParam("transaction_id") String transactionId) throws ProcessorException {
        TransactionStatistics transactionStats = new TransactionStatistics();
        List<Row> rows = null;
        try {
            log.info("get transaction status method is called");
            rows = paymentService.getTransaction(transactionId);
            Optional<Row> row = Optional.ofNullable(rows.stream().findFirst().orElse(null));
            transactionStats = mapRowToTransaction(row.orElse(null));
        } catch (ProcessorException e) {
            e.printStackTrace();
            transactionStats.setTransactionId(transactionId);
            transactionStats.setPaymentResponse(e.getMessage());
        }
        if(transactionStats==null) {
            transactionStats = new TransactionStatistics();
            transactionStats.setTransactionId(transactionId);
            transactionStats.setPaymentStatus(String.valueOf(PAYMENT_STATUS.NOT_FOUND));
        } else if(transactionStats.getPaymentStatus()==String.valueOf(PAYMENT_STATUS.PARKED_PENDING)) {
            String paymentReq = transactionStats.getPaymentRequest();
            PaymentRetry paymentRetry = paymentSwitch.checkPaymentStatus(paymentReq, transactionStats.getPaymentType());
            String updatedStatus = paymentRetry.getLastStatusCheck()!=PAYMENT_STATUS.PENDING
                    ? String.valueOf(paymentRetry.getLastStatusCheck()) : String.valueOf(PAYMENT_STATUS.PARKED_PENDING);
            transactionStats.setPaymentStatus(updatedStatus);
            transactionStats.setPaymentResponse(paymentRetry.getPaymentStatusCheckResponse().getResponseBody());
            transactionStats.setPaymentRequest(paymentRetry.getStatusCheckReqString());
            transactionStats.setResponseTimestamp(paymentRetry.getLastRetryDatetime().toString());
            Payment payment = new Payment();
            payment.setSettlementId(transactionStats.getSettlementId());
            payment.setPaymentType(transactionStats.getPaymentType());
            payment.setTransactionId(transactionStats.getTransactionId());
            payment.setPaymentRespDateTime(paymentRetry.getLastRetryDatetime());
            payment.setPaymentStatus(paymentRetry.getLastStatusCheck());
            payment.setPaymentRetry(paymentRetry);
            if(paymentRetry.getLastStatusCheck()==PAYMENT_STATUS.SUCCESS || paymentRetry.getLastStatusCheck()==PAYMENT_STATUS.FAILED) {
                producerService.sendPaymentSuccess(payment);
            }
        } else if(transactionStats.getPaymentStatus()==String.valueOf(PAYMENT_STATUS.DUPLICATE_SETTLEMENT_REJECTED)) {
            String refPmtStateString = "Duplicate transaction with settlement ID";
            transactionStats.setPaymentStatus(refPmtStateString);
        } else if(transactionStats.getPaymentStatus()==String.valueOf(PAYMENT_STATUS.DUPLICATE_TRANSACTION_REJECTED)) {
            String refPmtStateString = "Duplicate transaction";
            transactionStats.setPaymentStatus(refPmtStateString);
        }
        return transactionStats;
    }

    @PostMapping("/process-payment")
    public GPayResponse processPayment(@RequestBody String paymentRequest, @RequestParam("settlement_id") String settlementId,
                                       @RequestParam("priority_code") String priorityCode)
            throws ProcessorException {
        PAYMENT_STATUS paymentResp = PAYMENT_STATUS.TIMEOUT;
        GPayResponse gPayResponse = new GPayResponse();
        Payment pmt = new Payment(settlementId, priorityCode);//x-priority
        pmt.setPaymentRequest(paymentRequest);
        producerService.sendPaymentRequest(pmt);
        log.info("Controller uuid ::{}",pmt.getUuid());
        List<Row> list = null;
        try {
            list = paymentService.getDedupPayment(pmt);
        } catch (ProcessorException e) {
            e.printStackTrace();
            // Handle scenario: KSQLDb issue
            throw new ProcessorException(e.getMessage());
        }
        List<Payment> paymentRows = new ArrayList<>();
        list.stream().forEach(row -> paymentRows.add(mapRowToPayment(row)));
        Payment payment = null;
        if (paymentRows != null && paymentRows.size() > 0) {
            payment = paymentRows.get(0);
            pmt.setPaymentStatus(payment.getPaymentStatus());
            pmt.setPaymentReference(payment.getPaymentReference());
            paymentResp = pmt.getPaymentStatus();
            if(paymentResp==PAYMENT_STATUS.WIP) {
                // API call to payment switch
                Payment paymentFinal = paymentSwitch.processPayment(pmt);
                PaymentResponse pmtResp = paymentFinal.getPaymentResponse();
                gPayResponse = new GPayResponse(paymentFinal.getSettlementId(), paymentFinal.getTransactionId(),
                        String.valueOf(paymentFinal.getPaymentStatus()), paymentFinal.getPaymentResponse());
                if(paymentFinal.getPaymentStatus()==PAYMENT_STATUS.SUCCESS) {
                    //paymentFinal.setPaymentStatus(PAYMENT_STATUS.SUCCESS);
                    producerService.sendPaymentSuccess(paymentFinal);
                } else if(paymentFinal.getPaymentStatus()==PAYMENT_STATUS.PENDING) {
                    //paymentFinal.setPaymentStatus(PAYMENT_STATUS.PENDING);
                    producerService.sendPaymentPending(paymentFinal);
                } else if(paymentFinal.getPaymentStatus()==PAYMENT_STATUS.WIP) {
                    producerService.sendPaymentDeadletter(paymentFinal);
                    paymentFinal.setPaymentStatus(PAYMENT_STATUS.PENDING);
                    producerService.sendPaymentPending(paymentFinal);
                } else if(paymentFinal.getPaymentStatus()==PAYMENT_STATUS.FAILED) {
                    log.info("{}::{}",paymentFinal.getSettlementId(),PAYMENT_STATUS.FAILED);
                    producerService.sendPaymentFailure(paymentFinal);
                }
            } else if(paymentResp==PAYMENT_STATUS.DUPLICATE_SETTLEMENT_REJECTED) {
                gPayResponse = new GPayResponse(pmt.getSettlementId(), pmt.getTransactionId(),
                        "Duplicate transaction with settlement ID", pmt.getPaymentReference(), pmt.getPaymentResponse());
                // Send to blocked topic
                pmt.setPaymentStatus(PAYMENT_STATUS.DUPLICATE_SETTLEMENT_REJECTED);
                producerService.sendPaymentBlocked(pmt);
            } else if(paymentResp==PAYMENT_STATUS.DUPLICATE_TRANSACTION_REJECTED) {
                gPayResponse = new GPayResponse(pmt.getSettlementId(), pmt.getTransactionId(), "Duplicate transaction",
                        pmt.getPaymentReference(), pmt.getPaymentResponse());
                // Send to blocked topic
                pmt.setPaymentStatus(PAYMENT_STATUS.DUPLICATE_TRANSACTION_REJECTED);
                //producerService.sendPaymentBlocked(pmt);
            }
        } else {
            gPayResponse = new GPayResponse(pmt.getSettlementId(), pmt.getTransactionId(),
                    "Timeout occurred. Please retry payment.");
        }
        return gPayResponse;
    }

    private TransactionStatistics mapRowToTransaction(Row row) {
        log.info("mapping row to transaction");
        TransactionStatistics transactionStats = null;
        if(row!=null) {
            transactionStats = new TransactionStatistics();
            transactionStats.setSettlementId(row.getString("SETTLEMENTID"));
            transactionStats.setTransactionId(row.getString("TRANSACTIONID"));
            transactionStats.setPaymentType(PAYMENT_TYPE.valueOf(row.getString("PAYMENTTYPE")));
            transactionStats.setResponseTimestamp(row.getString("PAYMENTRESPDATETIME"));
            PAYMENT_STATUS paymentStatus = PAYMENT_STATUS.valueOf(row.getString("PAYMENTSTATUS"));
            transactionStats.setPaymentStatus(String.valueOf(paymentStatus));
            if(paymentStatus==PAYMENT_STATUS.SUCCESS) {
                Object pmtRetry = row.getValue("PAYMENTRETRY");
                if(pmtRetry!=null) {
                    KsqlObject paymentRetry = row.getKsqlObject("PAYMENTRETRY");
                    Map<String, Object> paymentRetryMap = paymentRetry.getMap();
                    Map<String, String> paymentStatusCheckRespMap = (Map<String, String>) paymentRetryMap.get("PAYMENTSTATUSCHECKRESPONSE");
                    String paymentStatusCheckReq = (String) paymentRetryMap.get("PAYMENTSTATUSCHECKREQUEST");
                    if(paymentStatusCheckRespMap!=null) {
                        transactionStats.setResponseTimestamp((String) paymentRetryMap.get("LASTRETRYDATETIME"));
                        transactionStats.setPaymentResponse(paymentStatusCheckRespMap.get("RESPONSEBODY"));
                        transactionStats.setPaymentRequest(paymentStatusCheckReq);
                    } else {
                        KsqlObject paymentResponse = row.getKsqlObject("PAYMENTRESPONSE");
                        transactionStats.setPaymentResponse(paymentResponse.getString("RESPONSEBODY"));
                        transactionStats.setPaymentRequest(row.getString("PAYMENTREQSTRING"));
                    }
                } else {
                    KsqlObject paymentResponse = row.getKsqlObject("PAYMENTRESPONSE");
                    transactionStats.setPaymentResponse(paymentResponse.getString("RESPONSEBODY"));
                    transactionStats.setPaymentRequest(row.getString("PAYMENTREQSTRING"));
                }
            } else if(paymentStatus==PAYMENT_STATUS.FAILED) {
                KsqlObject paymentResponse = row.getKsqlObject("PAYMENTRESPONSE");
                transactionStats.setPaymentResponse(paymentResponse.getString("RESPONSEBODY"));
                transactionStats.setPaymentRequest(row.getString("PAYMENTREQSTRING"));
            } else if(paymentStatus==PAYMENT_STATUS.PENDING || paymentStatus==PAYMENT_STATUS.PARKED_PENDING) {
                Object pmtRetry = row.getValue("PAYMENTRETRY");
                if(pmtRetry!=null) {
                    KsqlObject paymentRetry = row.getKsqlObject("PAYMENTRETRY");
                    Map<String, Object> paymentRetryMap = paymentRetry.getMap();
                    Map<String, String> paymentStatusCheckRespMap = (Map<String, String>) paymentRetryMap.get("PAYMENTSTATUSCHECKRESPONSE");
                    String  paymentStatusCheckReq = (String) paymentRetryMap.get("PAYMENTSTATUSCHECKREQUEST");
                    if(paymentStatusCheckRespMap!=null) {
                        transactionStats.setPaymentResponse(paymentStatusCheckRespMap.get("RESPONSEBODY"));
                        transactionStats.setPaymentRequest(paymentStatusCheckReq);
                        transactionStats.setResponseTimestamp((String) paymentRetryMap.get("LASTRETRYDATETIME"));
                    } else {
                        KsqlObject paymentResponse = row.getKsqlObject("PAYMENTRESPONSE");
                        transactionStats.setPaymentResponse(paymentResponse.getString("RESPONSEBODY"));
                        transactionStats.setPaymentRequest(row.getString("PAYMENTREQSTRING"));
                    }
                }
            }
        }
        return transactionStats;
    }

    private Payment mapRowToPayment(Row row) {
        Payment payment = null;
        if(row!=null) {
            payment = new Payment();
            payment.setSettlementId(row.getString("SETTLEMENTID"));
            payment.setTransactionId(row.getString("TRANSACTIONID"));
            payment.setPaymentType(PAYMENT_TYPE.valueOf(row.getString("PAYMENTTYPE")));
            PAYMENT_STATUS pmtStatusSettlement = row.getString("PAYMENTSTATUSSETTLEMENT")!=null ?
                    PAYMENT_STATUS.valueOf(row.getString("PAYMENTSTATUSSETTLEMENT")) : null;
            PAYMENT_STATUS pmtStatusTransaction = row.getString("PAYMENTSTATUSTRANSACTION")!=null
                    ? PAYMENT_STATUS.valueOf(row.getString("PAYMENTSTATUSTRANSACTION")) : null;
            PAYMENT_STATUS pmtStatus = PAYMENT_STATUS.STATUS_UNKNOWN;
            PAYMENT_STATUS refPaymentState = PAYMENT_STATUS.STATUS_UNKNOWN;
            String settlementId = "";
            String transactionId = "";
            if(pmtStatusTransaction==PAYMENT_STATUS.DUPLICATE_REJECTED) {
                pmtStatus = PAYMENT_STATUS.DUPLICATE_TRANSACTION_REJECTED;
                refPaymentState = row.getString("REFPAYMENTSTATUSALT") !=null ?
                        PAYMENT_STATUS.valueOf(row.getString("REFPAYMENTSTATUSALT")) : null;
                settlementId = row.getString("SETTLEMENTIDSTATUSALT");
                transactionId = row.getString("TRANSACTIONIDSTATUSALT");
            } else if(pmtStatusSettlement==PAYMENT_STATUS.DUPLICATE_REJECTED) {
                pmtStatus = PAYMENT_STATUS.DUPLICATE_SETTLEMENT_REJECTED;
                refPaymentState = row.getString("REFPAYMENTSTATUS") !=null ?
                        PAYMENT_STATUS.valueOf(row.getString("REFPAYMENTSTATUS")) : null;
                settlementId = row.getString("SETTLEMENTIDSTATUS");
                transactionId = row.getString("TRANSACTIONIDSTATUS");
            } else {
                pmtStatus = pmtStatusSettlement !=null ? pmtStatusSettlement : pmtStatusTransaction;
                refPaymentState = row.getString("REFPAYMENTSTATUS") !=null ?
                        PAYMENT_STATUS.valueOf(row.getString("REFPAYMENTSTATUS")) : null;
                settlementId = row.getString("SETTLEMENTIDSTATUS");
                transactionId = row.getString("TRANSACTIONIDSTATUS");
            }
            payment.setPaymentStatus(pmtStatus);
            String refPmtStateString = String.valueOf(refPaymentState);
            if(refPaymentState==PAYMENT_STATUS.DUPLICATE_SETTLEMENT_REJECTED) {
                refPmtStateString = "Duplicate transaction with settlement ID";
            } else if(refPaymentState==PAYMENT_STATUS.DUPLICATE_TRANSACTION_REJECTED) {
                refPmtStateString = "Duplicate transaction";
            }
            PaymentReference pmtRef = new PaymentReference(settlementId, transactionId, refPmtStateString);
            payment.setPaymentReference(pmtRef);
        }
        return payment;
    }

}