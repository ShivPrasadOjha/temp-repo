package com.icici.gpayprocessor.joiner;

import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.enums.PAYMENT_STATUS;
import org.apache.kafka.streams.kstream.ValueJoiner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author aditya_shekhar on 2/27/2024
 */
public class TransactionStatusJoiner implements ValueJoiner<Payment, Payment, Payment>{
    private static final Logger log = LoggerFactory.getLogger(TransactionStatusJoiner.class);

    @Override
    public Payment apply(Payment payment1, Payment payment2) {
        log.info("calling TransactionStatusJoiner apply method::");
        Payment validPayment = null;
        if(payment1!=null && payment2==null) {
            validPayment = payment1;
        } else if(payment1==null && payment2!=null) {
            validPayment = payment2;
        } else if(payment1!=null && payment2!=null) {
            validPayment = payment2;
        }
        return validPayment;
    }

}
