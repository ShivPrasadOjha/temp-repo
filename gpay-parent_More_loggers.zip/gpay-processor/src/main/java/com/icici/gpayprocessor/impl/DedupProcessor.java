package com.icici.gpayprocessor.impl;

import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.exception.ProcessorException;
import com.icici.gpaycommon.serdes.PaymentSerdes;
import com.icici.gpaycommon.topic.KafkaTopics;
import com.icici.gpayprocessor.helper.PropertyHelper;
import com.icici.gpayprocessor.joiner.DedupPaymentJoiner;
import com.icici.gpayprocessor.joiner.ParkedPendingPaymentJoiner;
import com.icici.gpayprocessor.joiner.PendingPaymentJoiner;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.*;
import org.apache.kafka.streams.kstream.*;

import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public class DedupProcessor extends BaseProcessor {

    private static final Logger log = LoggerFactory.getLogger(DedupProcessor.class);
    private Properties props;
    {
        props = PropertyHelper.getInstance().getProperties();
    }
    private String pmtReqTopic = KafkaTopics.GPAY_PMT_REQUEST_TOPIC;
    private String pmtValidStatusTopic = KafkaTopics.GPAY_PMT_VALID_STATUS_TOPIC;
    private String pmtValidStatusLogTopic = KafkaTopics.GPAY_PMT_VALID_STATUS_LOG_TOPIC;
    private String pmtRetryTrackerTopic = KafkaTopics.GPAY_PMT_PENDING_TRACKER_TOPIC;
    private String pmtPendingParkedTopic = KafkaTopics.GPAY_PMT_PENDING_PARKED_TOPIC;
    private String pmtCompleteTopic = KafkaTopics.GPAY_PMT_COMPLETE_TOPIC;
    private String pmtBlockedTopic = KafkaTopics.GPAY_PMT_BLOCKED_TOPIC;
    private String appID = props.getProperty("GPAY_DEDUP_APP_ID");
    private StreamsBuilder builder = null;

    public DedupProcessor() throws ProcessorException {
        super();
    }

    @Override
    public Topology build(StreamsBuilder builder) {
        builder = new StreamsBuilder();
        KStream<String, Payment> pmtRequest = builder.stream(pmtReqTopic, Consumed.with(Serdes.String(), PaymentSerdes.serde()));
        KTable<String, Payment> pmtRetryTracker = builder.table(pmtRetryTrackerTopic, Consumed.with(Serdes.String(), PaymentSerdes.serde()));
        KTable<String, Payment> pmtPendingParked = builder.table(pmtPendingParkedTopic, Consumed.with(Serdes.String(), PaymentSerdes.serde()));
        KTable<String, Payment> pmtValidReq = builder.table(pmtValidStatusTopic, Consumed.with(Serdes.String(), PaymentSerdes.serde()));
        KTable<String, Payment> pmtComplete = builder.table(pmtCompleteTopic, Consumed.with(Serdes.String(), PaymentSerdes.serde()));
        KTable<String, Payment> pmtBlocked = builder.table(pmtBlockedTopic, Consumed.with(Serdes.String(), PaymentSerdes.serde()));

        ValueJoiner<Payment, Payment, Payment> dedupJoiner = new DedupPaymentJoiner();
        ValueJoiner<Payment, Payment, Payment> pendingPaymentJoiner = new PendingPaymentJoiner();
        ValueJoiner<Payment, Payment, Payment> parkedPendingPaymentJoiner = new ParkedPendingPaymentJoiner();

        KTable<String, Payment> paymentRetryEnriched = pmtRetryTracker.leftJoin(pmtComplete, pendingPaymentJoiner);
        KTable<String, Payment> paymentParkedPaymentEnriched = pmtPendingParked.leftJoin(pmtComplete, parkedPendingPaymentJoiner);
        KTable<String, Payment> paymentValidReqEnriched = pmtValidReq.join(pmtComplete, dedupJoiner);

        paymentRetryEnriched.filter( (k, v) -> v!=null).toStream().filter((k,v) -> v!=null)
                .peek((k,v) -> log.info("paymentRetryEnriched:: {},--{},--{},--{}",k,v.getSettlementId(),v.getTransactionId(),v.getPaymentStatus()));


        paymentParkedPaymentEnriched.toStream().filter((k,v) -> v!=null)
                .peek((k,v) -> log.info("paymentParkedPaymentEnriched:: {},--{},--{},--{}",k,v.getSettlementId(),v.getTransactionId(),v.getPaymentStatus()));

        paymentValidReqEnriched.toStream().filter((k,v) -> v!=null)
                .peek((k,v) -> log.info("paymentValidReqEnriched:: {},--{},--{},--{}",k,v.getSettlementId(),v.getTransactionId(),v.getPaymentStatus()));


        KStream<String, Payment> dedupPmtReq0 = pmtRequest.leftJoin(pmtBlocked, dedupJoiner);
        KStream<String, Payment> dedupPmtReq1 = dedupPmtReq0.leftJoin(pmtComplete, dedupJoiner);
        KStream<String, Payment> dedupPmtReq2 = dedupPmtReq1.leftJoin(paymentRetryEnriched, dedupJoiner);
        KStream<String, Payment> dedupPmtReq3 = dedupPmtReq2.leftJoin(paymentParkedPaymentEnriched, dedupJoiner);
        KStream<String, Payment> dedupPmtReq4 = dedupPmtReq3.leftJoin(paymentValidReqEnriched, dedupJoiner);

        KStream<String, Payment> dedupPmtReqRekeyed = dedupPmtReq4
                .filter((k ,v) -> v!=null)
                .map( (key, val) -> KeyValue.pair(val.getUuid().toString(), val));
        dedupPmtReq4.filter((k ,v) -> v!=null).peek( (key, value) -> {
            log.info("key:{}",key);
            log.info("Value:{}::{}",value.getSettlementId(),value.getPaymentStatus());
        });
        dedupPmtReq4.filter((k ,v) -> v!=null).to(pmtValidStatusTopic, Produced.with(Serdes.String(), PaymentSerdes.serde()));
        dedupPmtReqRekeyed.peek( (key, value) -> {
            log.info("key:{}",key);
            log.info("Value:{}::{}",value.getSettlementId(),value.getPaymentStatus());
        });
        dedupPmtReqRekeyed.to(pmtValidStatusLogTopic, Produced.with(Serdes.String(), PaymentSerdes.serde()));
        Topology topology = builder.build();
        return topology;
    }

    @Override
    public void run() {
        Topology topology = build(builder);
        super.streamsConfiguration.put(StreamsConfig.APPLICATION_ID_CONFIG, appID);
        KafkaStreams streams = new KafkaStreams(topology, super.streamsConfiguration);
        streams.start();
    }

    /*public static void main(String[] args) throws ProcessorException {
        System.out.println("DedupProcessor starting.....");
        BaseProcessor bp = new DedupProcessor();
        bp.run();
        System.out.println("DedupProcessor running now.....");
    }*/
}