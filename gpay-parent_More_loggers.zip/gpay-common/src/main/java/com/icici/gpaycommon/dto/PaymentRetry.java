package com.icici.gpaycommon.dto;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.icici.gpaycommon.enums.PAYMENT_STATUS;
import com.icici.gpaycommon.enums.PAYMENT_TYPE;
import com.icici.gpaycommon.pojo.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Date;

/**
 * @author aditya_shekhar on 2/5/2024
 */
public class PaymentRetry {

    private Date enqueueDatetime;
    private Date dequeueDatetime;
    private int retryCount = 0;
    private Date lastRetryDatetime;
    @JsonTypeInfo(use=JsonTypeInfo.Id.CLASS, include=JsonTypeInfo.As.PROPERTY, property="@class")
    private PaymentStatusCheckRequest paymentStatusCheckRequest;
    @JsonTypeInfo(use=JsonTypeInfo.Id.CLASS, include=JsonTypeInfo.As.PROPERTY, property="@class")
    private PaymentStatusCheckResponse paymentStatusCheckResponse;
    private PAYMENT_STATUS lastStatusCheck;
    private String statusCheckReqString;

    private static final Logger log = LoggerFactory.getLogger(PaymentRetry.class);

    public PaymentRetry() {
    }

    public PaymentRetry(Date enqueueDatetime, int retryCount, Date lastRetryDatetime) {
        this.enqueueDatetime = enqueueDatetime;
        this.retryCount = retryCount;
        this.lastRetryDatetime = lastRetryDatetime;
    }

    public Date getEnqueueDatetime() {
        return enqueueDatetime;
    }

    public void setEnqueueDatetime(Date enqueueDatetime) {
        this.enqueueDatetime = enqueueDatetime;
    }

    public Date getDequeueDatetime() {
        return dequeueDatetime;
    }

    public void setDequeueDatetime(Date dequeueDatetime) {
        this.dequeueDatetime = dequeueDatetime;
    }

    public int getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(int retryCount) {
        this.retryCount = retryCount;
    }

    public Date getLastRetryDatetime() {
        return lastRetryDatetime;
    }

    public void setLastRetryDatetime(Date lastRetryDatetime) {
        this.lastRetryDatetime = lastRetryDatetime;
    }

    public PaymentStatusCheckRequest getPaymentStatusCheckRequest() {
        return paymentStatusCheckRequest;
    }

    public void setPaymentStatusCheckRequest(PaymentStatusCheckRequest paymentStatusCheckRequest) {
        this.paymentStatusCheckRequest = paymentStatusCheckRequest;
    }

    public void setPaymentStatusCheckRequest(String paymentStatusCheckRequestString, PAYMENT_TYPE paymentType) {
        ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);
        om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        om.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        try {
            switch (paymentType) {
                case IMPS:
                    RequestStatusCheckIMPS requestStatusCheckIMPS = om.readValue(paymentStatusCheckRequestString, RequestStatusCheckIMPS.class);
                    this.paymentStatusCheckRequest = requestStatusCheckIMPS;
                    break;
                case UPI:
                    log.info("paymentStatusCheckRequestString {}",paymentStatusCheckRequestString);
                    RequestStatusCheckUPI requestStatusCheckUPI = om.readValue(paymentStatusCheckRequestString, RequestStatusCheckUPI.class);
                    this.paymentStatusCheckRequest = requestStatusCheckUPI;
                    break;
                case NEFT:
                    RequestStatusCheckNEFT requestStatusCheckNEFT = om.readValue(paymentStatusCheckRequestString, RequestStatusCheckNEFT.class);
                    this.paymentStatusCheckRequest = requestStatusCheckNEFT;
                    break;
                case RTGS:
                    RequestStatusCheckRTGS requestStatusCheckRTGS = om.readValue(paymentStatusCheckRequestString, RequestStatusCheckRTGS.class);
                    this.paymentStatusCheckRequest = requestStatusCheckRTGS;
                    break;
                default:
                    this.paymentStatusCheckRequest = null;
            }
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    public PaymentStatusCheckResponse getPaymentStatusCheckResponse() {
        return paymentStatusCheckResponse;
    }

    public void setPaymentStatusCheckResponse(PaymentStatusCheckResponse paymentStatusCheckResponse) {
        this.paymentStatusCheckResponse = paymentStatusCheckResponse;
    }

    public void setPaymentStatusCheckResponse(String paymentStatusCheckResponseString, PAYMENT_TYPE paymentType) {
        ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);
        om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        om.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        try {
            switch (paymentType) {
                case IMPS:
                    ResponseStatusCheckIMPS responseStatusCheckIMPS = om.readValue(paymentStatusCheckResponseString, ResponseStatusCheckIMPS.class);
                    this.paymentStatusCheckResponse = responseStatusCheckIMPS;
                    break;
                case UPI:
                    ResponseStatusCheckUPI responseStatusCheckUPI = om.readValue(paymentStatusCheckResponseString, ResponseStatusCheckUPI.class);
                    this.paymentStatusCheckResponse = responseStatusCheckUPI;
                    break;
                case NEFT:
                    ResponseStatusCheckNEFT responseStatusCheckNEFT = om.readValue(paymentStatusCheckResponseString, ResponseStatusCheckNEFT.class);
                    this.paymentStatusCheckResponse = responseStatusCheckNEFT;
                    break;
                case RTGS:
                    ResponseStatusCheckRTGS responseStatusCheckRTGS = om.readValue(paymentStatusCheckResponseString, ResponseStatusCheckRTGS.class);
                    this.paymentStatusCheckResponse = responseStatusCheckRTGS;
                    break;
                default:
                    this.paymentStatusCheckRequest = null;
            }
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    public PAYMENT_STATUS getLastStatusCheck() {
        return lastStatusCheck;
    }

    public void setLastStatusCheck(PAYMENT_STATUS lastStatusCheck) {
        this.lastStatusCheck = lastStatusCheck;
    }

    public String getStatusCheckReqString() {
        return statusCheckReqString;
    }

    public void setStatusCheckReqString(String statusCheckReqString) {
        this.statusCheckReqString = statusCheckReqString;
    }
}
