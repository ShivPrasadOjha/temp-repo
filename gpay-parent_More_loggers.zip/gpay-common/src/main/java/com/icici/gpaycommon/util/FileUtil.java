package com.icici.gpaycommon.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.StandardCopyOption;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author aditya_shekhar on 1/25/2024
 */
public class FileUtil {
    private static final Logger log = LoggerFactory.getLogger(FileUtil.class);

    public static void inputStreamToFile(InputStream inputStream, String fileName, String path) throws IOException {
        File targetFile = new File(path +  "/" +fileName);
        log.info("path{}",path);
        log.info("fileName{}",fileName);
        java.nio.file.Files.copy(inputStream, targetFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //IOUtils.closeQuietly(initialStream);
    }
}
