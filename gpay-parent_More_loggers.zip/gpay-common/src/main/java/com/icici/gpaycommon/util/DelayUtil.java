package com.icici.gpaycommon.util;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author aditya_shekhar on 1/21/2024
 */
public class DelayUtil {

    private static final Logger log = LoggerFactory.getLogger(DelayUtil.class);
    /**
     *  Delays the current thread execution.
     *  The thread loses ownership of any monitors.
     *  Quits immediately if the thread is interrupted
     *
     * @param durationInMillis the time duration in milliseconds
     */
    public void delay(final long durationInMillis) {
        delay(durationInMillis, TimeUnit.MILLISECONDS);
    }

    /**
     * @param duration the time duration in the given {@code sourceUnit}
     * @param unit
     */
    public void delay(final long duration, final TimeUnit unit) {
        long currentTime = System.currentTimeMillis();
        long deadline = currentTime+unit.toMillis(duration);
        log.info("deadLine{}",deadline);
        ReentrantLock lock = new ReentrantLock();
        Condition waitCondition = lock.newCondition();

        while ((deadline-currentTime)>0) {
            try {
                lock.lockInterruptibly();
                waitCondition.await(deadline - currentTime, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                lock.unlock();
            }
            currentTime = System.currentTimeMillis();
            log.info("currentTime{}",currentTime);
        }
    }
}
