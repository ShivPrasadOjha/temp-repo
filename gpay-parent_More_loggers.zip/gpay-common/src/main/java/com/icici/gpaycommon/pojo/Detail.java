package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Detail {

    @JsonProperty("errorcode")
    private String errorcode;
    @JsonProperty("reason")
    private String reason;

    public Detail() {
    }

    /**
     *
     * @param reason
     * @param errorcode
     */
    public Detail(String errorcode, String reason) {
        super();
        this.errorcode = errorcode;
        this.reason = reason;
    }

    public String getErrorcode() {
        return errorcode;
    }

    public void setErrorcode(String errorcode) {
        this.errorcode = errorcode;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

}
