package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PaymentRequestCIBNEFT{

    @JsonProperty("AGGRID")
    private String aggrid;
    @JsonProperty("CORPID")
    private String corpid;
    @JsonProperty("USERID")
    private String userid;
    @JsonProperty("URN")
    private String urn;
    @JsonProperty("AGGRNAME")
    private String aggrname;
    @JsonProperty("UNIQUEID")
    private String uniqueid;
    @JsonProperty("DEBITACC")
    private String debitacc;
    @JsonProperty("CREDITACC")
    private String creditacc;
    @JsonProperty("IFSC")
    private String ifsc;
    @JsonProperty("AMOUNT")
    private String amount;
    @JsonProperty("CURRENCY")
    private String currency;
    @JsonProperty("TXNTYPE")
    private String txntype;
    @JsonProperty("PAYEENAME")
    private String payeename;
    @JsonProperty("REMARKS")
    private String remarks;
    @JsonProperty("WORKFLOW_REQD")
    private String workflowReqd;

    public PaymentRequestCIBNEFT() {
    }

    public PaymentRequestCIBNEFT(String aggrid, String corpid, String userid, String urn, String aggrname, String uniqueid, String debitacc, String creditacc, String ifsc, String amount, String currency, String txntype, String payeename, String remarks, String workflowReqd) {
        super();
        this.aggrid = aggrid;
        this.corpid = corpid;
        this.userid = userid;
        this.urn = urn;
        this.aggrname = aggrname;
        this.uniqueid = uniqueid;
        this.debitacc = debitacc;
        this.creditacc = creditacc;
        this.ifsc = ifsc;
        this.amount = amount;
        this.currency = currency;
        this.txntype = txntype;
        this.payeename = payeename;
        this.remarks = remarks;
        this.workflowReqd = workflowReqd;
    }

    @JsonProperty("AGGRID")
    public String getAggrid() {
        return aggrid;
    }

    @JsonProperty("AGGRID")
    public void setAggrid(String aggrid) {
        this.aggrid = aggrid;
    }

    @JsonProperty("CORPID")
    public String getCorpid() {
        return corpid;
    }

    @JsonProperty("CORPID")
    public void setCorpid(String corpid) {
        this.corpid = corpid;
    }

    @JsonProperty("USERID")
    public String getUserid() {
        return userid;
    }

    @JsonProperty("USERID")
    public void setUserid(String userid) {
        this.userid = userid;
    }

    @JsonProperty("URN")
    public String getUrn() {
        return urn;
    }

    @JsonProperty("URN")
    public void setUrn(String urn) {
        this.urn = urn;
    }

    @JsonProperty("AGGRNAME")
    public String getAggrname() {
        return aggrname;
    }

    @JsonProperty("AGGRNAME")
    public void setAggrname(String aggrname) {
        this.aggrname = aggrname;
    }

    @JsonProperty("UNIQUEID")
    public String getUniqueid() {
        return uniqueid;
    }

    @JsonProperty("UNIQUEID")
    public void setUniqueid(String uniqueid) {
        this.uniqueid = uniqueid;
    }

    @JsonProperty("DEBITACC")
    public String getDebitacc() {
        return debitacc;
    }

    @JsonProperty("DEBITACC")
    public void setDebitacc(String debitacc) {
        this.debitacc = debitacc;
    }

    @JsonProperty("CREDITACC")
    public String getCreditacc() {
        return creditacc;
    }

    @JsonProperty("CREDITACC")
    public void setCreditacc(String creditacc) {
        this.creditacc = creditacc;
    }

    @JsonProperty("IFSC")
    public String getIfsc() {
        return ifsc;
    }

    @JsonProperty("IFSC")
    public void setIfsc(String ifsc) {
        this.ifsc = ifsc;
    }

    @JsonProperty("AMOUNT")
    public String getAmount() {
        return amount;
    }

    @JsonProperty("AMOUNT")
    public void setAmount(String amount) {
        this.amount = amount;
    }

    @JsonProperty("CURRENCY")
    public String getCurrency() {
        return currency;
    }

    @JsonProperty("CURRENCY")
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @JsonProperty("TXNTYPE")
    public String getTxntype() {
        return txntype;
    }

    @JsonProperty("TXNTYPE")
    public void setTxntype(String txntype) {
        this.txntype = txntype;
    }

    @JsonProperty("PAYEENAME")
    public String getPayeename() {
        return payeename;
    }

    @JsonProperty("PAYEENAME")
    public void setPayeename(String payeename) {
        this.payeename = payeename;
    }

    @JsonProperty("REMARKS")
    public String getRemarks() {
        return remarks;
    }

    @JsonProperty("REMARKS")
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @JsonProperty("WORKFLOW_REQD")
    public String getWorkflowReqd() {
        return workflowReqd;
    }

    @JsonProperty("WORKFLOW_REQD")
    public void setWorkflowReqd(String workflowReqd) {
        this.workflowReqd = workflowReqd;
    }

}