package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentResponse;

public class PaymentResponseErrorRTGS implements PaymentResponse{

    @JsonProperty("STATUS")
    private String status;
    @JsonProperty("MESSAGE")
    private String message;
    @JsonProperty("RESPONSE")
    private String response;

    @JsonIgnore
    private int responseCode;
    @JsonIgnore
    private String responseBody;

    /**
     * No args constructor for use in serialization
     *
     */
    public PaymentResponseErrorRTGS() {
    }

    /**
     *
     * @param response
     * @param message
     * @param status
     */
    public PaymentResponseErrorRTGS(String status, String message, String response) {
        super();
        this.status = status;
        this.message = message;
        this.response = response;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    @Override
    public int getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    @Override
    public String getResponseBody() {
        return responseBody;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }
}