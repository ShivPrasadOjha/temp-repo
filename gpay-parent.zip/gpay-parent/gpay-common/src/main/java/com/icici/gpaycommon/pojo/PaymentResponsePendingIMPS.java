package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentResponse;

/**
 * @author aditya_shekhar on 2/14/2024
 */
public class PaymentResponsePendingIMPS implements PaymentResponse {

    @JsonProperty("ActCode")
    private String actCode;
    @JsonProperty("Response")
    private String response;
    @JsonProperty("BankRRN")
    private String bankRRN;
    @JsonProperty("BeneName")
    private String beneName;
    @JsonProperty("TranRefNo")
    private String tranRefNo;

    @JsonIgnore
    private int responseCode;
    @JsonIgnore
    private String responseBody;

    public PaymentResponsePendingIMPS() {
    }

    public PaymentResponsePendingIMPS(String actCode, String response, String bankRRN, String beneName, String tranRefNo, int responseCode,
                                      String responseBody) {
        this.actCode = actCode;
        this.response = response;
        this.bankRRN = bankRRN;
        this.beneName = beneName;
        this.tranRefNo = tranRefNo;
        this.responseCode = responseCode;
        this.responseBody = responseBody;
    }

    public String getActCode() {
        return actCode;
    }

    public void setActCode(String actCode) {
        this.actCode = actCode;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getBankRRN() {
        return bankRRN;
    }

    public void setBankRRN(String bankRRN) {
        this.bankRRN = bankRRN;
    }

    public String getBeneName() {
        return beneName;
    }

    public void setBeneName(String beneName) {
        this.beneName = beneName;
    }

    public String getTranRefNo() {
        return tranRefNo;
    }

    public void setTranRefNo(String tranRefNo) {
        this.tranRefNo = tranRefNo;
    }

    @Override
    public int getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    @Override
    public String getResponseBody() {
        return responseBody;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }
}
