package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentStatusCheckRequest;

public class RequestStatusCheckFT implements PaymentStatusCheckRequest {

    @JsonProperty("AGGRID")
    private String aggrid;
    @JsonProperty("CORPID")
    private String corpid;
    @JsonProperty("USERID")
    private String userid;
    @JsonProperty("URN")
    private String urn;
    @JsonProperty("UNIQUEID")
    private String uniqueid;


    /**
     * No args constructor for use in serialization
     *
     */
    public RequestStatusCheckFT() {
    }

    /**
     *
     * @param urn
     * @param corpid
     * @param userid
     * @param aggrid
     * @param uniqueid
     */
    public RequestStatusCheckFT(String aggrid, String corpid, String userid, String urn, String uniqueid) {
        super();
        this.aggrid = aggrid;
        this.corpid = corpid;
        this.userid = userid;
        this.urn = urn;
        this.uniqueid = uniqueid;
    }


    public String getAggrid() {
        return aggrid;
    }

    public void setAggrid(String aggrid) {
        this.aggrid = aggrid;
    }

    public String getCorpid() {
        return corpid;
    }

    public void setCorpid(String corpid) {
        this.corpid = corpid;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getUrn() {
        return urn;
    }

    public void setUrn(String urn) {
        this.urn = urn;
    }

    public String getUniqueid() {
        return uniqueid;
    }

    public void setUniqueid(String uniqueid) {
        this.uniqueid = uniqueid;
    }
}
