package com.icici.gpaycommon.dto;

/**
 * @author aditya_shekhar on 2/23/2024
 */
public class TransactionStatus {

    private String settlementId;
    private String transactionId;
    private String paymentStatus;
    private PaymentResponse paymentResponse;

    public TransactionStatus(String settlementId, String transactionId, String paymentStatus, PaymentResponse paymentResponse) {
        this.settlementId = settlementId;
        this.transactionId = transactionId;
        this.paymentStatus = paymentStatus;
        this.paymentResponse = paymentResponse;
    }

    public String getSettlementId() {
        return settlementId;
    }

    public void setSettlementId(String settlementId) {
        this.settlementId = settlementId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public PaymentResponse getPaymentResponse() {
        return paymentResponse;
    }

    public void setPaymentResponse(PaymentResponse paymentResponse) {
        this.paymentResponse = paymentResponse;
    }
}
