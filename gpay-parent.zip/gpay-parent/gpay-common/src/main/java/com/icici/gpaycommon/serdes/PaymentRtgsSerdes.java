package com.icici.gpaycommon.serdes;

import com.icici.gpaycommon.deserializer.PaymentDeserializer;
import com.icici.gpaycommon.deserializer.PaymentRtgsDeserializer;
import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.serializer.PaymentRtgsSerializer;
import com.icici.gpaycommon.serializer.PaymentSerializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public final class PaymentRtgsSerdes{

    private PaymentRtgsSerdes() {}
    public static Serde<Payment> serde() {
        PaymentRtgsSerializer<Payment> serializer = new PaymentRtgsSerializer<>();
        PaymentRtgsDeserializer<Payment> deserializer = new PaymentRtgsDeserializer<>(Payment.class);
        return Serdes.serdeFrom(serializer, deserializer);
    }
}
