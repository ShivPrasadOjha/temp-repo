package com.icici.gpaycommon.enums;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public enum PAYMENT_TYPE{
    UPI, IMPS, NEFT, RTGS, FT;
}
