package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentRequest;

public class PaymentRequestIMPS implements PaymentRequest {

    @JsonProperty("localTxnDtTime")
    private String localTxnDtTime;
    @JsonProperty("beneAccNo")
    private String beneAccNo;
    @JsonProperty("beneIFSC")
    private String beneIFSC;
    @JsonProperty("amount")
    private String amount;
    @JsonProperty("tranRefNo")
    private String tranRefNo;
    @JsonProperty("paymentRef")
    private String paymentRef;
    @JsonProperty("senderName")
    private String senderName;
    @JsonProperty("mobile")
    private String mobile;
    @JsonProperty("retailerCode")
    private String retailerCode;
    @JsonProperty("passCode")
    private String passCode;
    @JsonProperty("bcID")
    private String bcID;

    /**
     * No args constructor for use in serialization
     *
     */
    public PaymentRequestIMPS() {
    }

    /**
     *
     * @param amount
     * @param senderName
     * @param bcID
     * @param tranRefNo
     * @param localTxnDtTime
     * @param beneIFSC
     * @param mobile
     * @param beneAccNo
     * @param retailerCode
     * @param passCode
     * @param paymentRef
     */
    public PaymentRequestIMPS(String localTxnDtTime, String beneAccNo, String beneIFSC, String amount, String tranRefNo, String paymentRef, String senderName, String mobile, String retailerCode, String passCode, String bcID) {
        super();
        this.localTxnDtTime = localTxnDtTime;
        this.beneAccNo = beneAccNo;
        this.beneIFSC = beneIFSC;
        this.amount = amount;
        this.tranRefNo = tranRefNo;
        this.paymentRef = paymentRef;
        this.senderName = senderName;
        this.mobile = mobile;
        this.retailerCode = retailerCode;
        this.passCode = passCode;
        this.bcID = bcID;
    }

    public String getLocalTxnDtTime() {
        return localTxnDtTime;
    }

    public void setLocalTxnDtTime(String localTxnDtTime) {
        this.localTxnDtTime = localTxnDtTime;
    }

    public String getBeneAccNo() {
        return beneAccNo;
    }

    public void setBeneAccNo(String beneAccNo) {
        this.beneAccNo = beneAccNo;
    }

    public String getBeneIFSC() {
        return beneIFSC;
    }

    public void setBeneIFSC(String beneIFSC) {
        this.beneIFSC = beneIFSC;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getTranRefNo() {
        return tranRefNo;
    }

    public void setTranRefNo(String tranRefNo) {
        this.tranRefNo = tranRefNo;
    }

    public String getPaymentRef() {
        return paymentRef;
    }

    public void setPaymentRef(String paymentRef) {
        this.paymentRef = paymentRef;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getRetailerCode() {
        return retailerCode;
    }

    public void setRetailerCode(String retailerCode) {
        this.retailerCode = retailerCode;
    }

    public String getPassCode() {
        return passCode;
    }

    public void setPassCode(String passCode) {
        this.passCode = passCode;
    }

    public String getBcID() {
        return bcID;
    }

    public void setBcID(String bcID) {
        this.bcID = bcID;
    }

}