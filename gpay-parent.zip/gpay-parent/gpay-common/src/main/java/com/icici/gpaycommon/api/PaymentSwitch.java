package com.icici.gpaycommon.api;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.icici.gpaycommon.dto.*;
import com.icici.gpaycommon.enums.PAYMENT_STATUS;
import com.icici.gpaycommon.enums.PAYMENT_TYPE;
import com.icici.gpaycommon.exception.ProcessorException;
import com.icici.gpaycommon.helper.PropertyHelper;
import com.icici.gpaycommon.pojo.*;
import okhttp3.*;

import java.io.IOException;
import java.net.http.HttpClient;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * @author aditya_shekhar on 2/6/2024
 */
public class PaymentSwitch {

    private Properties props;
    {
        try {
            props = PropertyHelper.getInstance().getProperties();
        } catch (ProcessorException e) {
            throw new RuntimeException("Exception thrown while initializing PropertyHelper");
        }
    }

    private final String paymentUpiUrl = props.getProperty("paymentUpiUrl");
    private final String paymentImpsUrl = props.getProperty("paymentImpsUrl");
    private final String paymentNeftUrl = props.getProperty("paymentNeftUrl");
    private final String paymentRtgsUrl = props.getProperty("paymentRtgsUrl");
    private String paymentUpiStatusUrl = props.getProperty("paymentUpiStatusUrl");
    private final String paymentImpsStatusUrl = props.getProperty("paymentImpsStatusUrl");
    private String paymentNeftStatusUrl = props.getProperty("paymentNeftStatusUrl");
    private final String paymentRtgsStatusUrl = props.getProperty("paymentRtgsStatusUrl");
    private final String paymentFtUrl = props.getProperty("paymentFtUrl");
    private String paymentFtStatusUrl = props.getProperty("paymentFtStatusUrl");
    private static List<String> upiPaymentSuccessCodes;
    private static List<String> upiPaymentErrorCodes;
    private static List<String> upiPaymentPendingCodes;
    private static List<String> upiStatusCheckSuccessCodes;
    private static List<String> upiStatusCheckErrorCodes;
    private static List<String> upiStatusCheckPendingCodes;
    private static List<String> impsPaymentSuccessCodes;
    private static List<String> impsPaymentErrorCodes;
    private static List<String> impsStatusCheckSuccessCodes;
    private static List<String> impsStatusCheckErrorCodes;
    private static List<String> impsStatusCheckPendingCodes;
    private static List<String> impsPaymentPendingCodes;

    static {
        String[] upiPaymentSuccess = {"0"};
        String[] upiPaymentError = {"11", "12", "13", "14", "37", "39", "31", "XH", "ZD", "XP", "XV", "YC", "YE", "UT", "U01", "U07",
                "U08", "U10", "U13", "U16", "U17", "U55", "U49", "U50", "U53", "XQ", "XS", "XU", "XW", "Y1", "YB", "YD", "YF",
                "0U11", "XY", "U29", "U30", "U31", "U32", "U33", "U34", "U67", "1", "4", "9", "10", "16", "17", "18", "23", "38",
                "55", "U09", "U17", "U18", "U26", "U80", "27", "1025", "98", "M3", "M1", "1036", "Z9", "U96", "U78", "B03", "B3", "IR",
                "NO", "UX", "XB", "XC", "YG", "Z7", "ZE", "ZH", "ZX", "ZY", "T02", "T03", "T04", "T05", "T14", "A09", "R06", "282", "G26",
                "UB7", "62", "63", "64", "65", "66", "67", "68", "69", "ZO", "ZG", "X1", "Z8", "M4", "XZ", "96", "Z5", "ZI", "51", "36",
                "K1", "53", "B07", "32", "22", "33", "CC8", "G27", "S93", "S94", "S95", "S96", "S97", "S98"};
        String[] upiPaymentPending = {"5", "91", "U66", "6", "9999", "XF", "XJ", "XK", "U05", "U28", "U51", "L05", "L16", "71", "72", "73",
                "74", "L06", "L07", "L08", "L09", "L10", "L11", "L12", "L13", "L14", "L15", "L17", "L18", "L19", "L20", "U52", "U54", "U56",
                "U57", "U58", "U59", "U60", "U61", "U62", "U63", "U64", "U65", "U27", "F01", "F02", "F03", "F04", "F05", "F06", "F07", "F08",
                "F09", "F10", "ZM", "XL", "XN", "XR", "XM", "XO", "RN", "AM", "ZA", "BT", "RB", "RR", "RP", "U68", "U69", "U70", "2", "3",
                "7", "8", "15", "U48", "U88", "101", "95", "99", "94", "92", "T13", "1033", "U90", "U91", "U86", "U89", "U81", "U84", "1830",
                "U92", "U93", "U94", "1051"};
        upiPaymentSuccessCodes = Arrays.asList(upiPaymentSuccess);
        upiPaymentErrorCodes = Arrays.asList(upiPaymentError);
        upiPaymentPendingCodes = Arrays.asList(upiPaymentPending);

        String[] upiStatusCheckSuccess = {"0"};
        String[] upiStatusCheckError = {"XH", "ZD", "XP", "XV", "YC", "YE", "UT", "U17", "U28", "U50", "U53", "XQ", "XS", "XU", "XW", "Y1",
                "YB", "YD", "YF", "0U11", "XY", "RR", "U29", "U30", "U31", "U32", "U33", "U34", "U67", "U09", "U17", "U18", "U26", "U80",
                "U88", "M3", "U90", "U91", "U86", "U89", "U92", "U93", "U94", "Z9", "U96", "U78", "T14", "B07", "CC8", "G27", "S93", "S94",
                "S95", "S96", "S97", "S98"};
        String[] upiStatusCheckPending = {"5", "U66", "6", "12", "13", "14", "37", "39", "31", "9999", "XF", "XJ", "XK", "U01", "U05",
                "U07", "U08", "U10", "U13", "U16", "U51", "U55", "L05", "L16", "71", "72", "73", "74", "L06", "L07", "L08", "L09", "L10",
                "L11", "L12", "L13", "L14", "L15", "L17", "L18", "L19", "L20", "U49", "U52", "U54", "U56", "U57", "U58", "U59", "U60", "U61",
                "U62", "U63", "U64", "U65", "U27", "F01", "F02", "F03", "F04", "F05", "F06", "F07", "F08", "F09", "F10", "ZM", "XL", "XN",
                "XR", "XM", "XO", "RN", "AM", "ZA", "RP", "U69", "U70", "1", "2", "3", "4", "7", "8", "9", "10", "15", "16", "17", "18",
                "23", "38", "55", "U48", "27", "1025", "101", "98", "95", "99", "94", "92", "T13", "M1", "1033", "U81", "U84", "1036",
                "1830", "B03", "B3", "IR", "NO", "UX", "XB", "XC", "YG", "Z7", "ZE", "ZH", "ZX", "ZY", "T02", "T03", "T04", "T05", "A09",
                "R06", "1051", "282", "G26", "UB7", "62", "63", "64", "65", "66", "67", "68", "69", "ZO", "ZG", "X1", "Z8", "M4", "XZ",
                "96", "Z5", "ZI", "51", "36", "K1", "53", "32", "22", "33"};
        upiStatusCheckSuccessCodes = Arrays.asList(upiStatusCheckSuccess);
        upiStatusCheckErrorCodes = Arrays.asList(upiStatusCheckError);
        upiStatusCheckPendingCodes = Arrays.asList(upiStatusCheckPending);

        String[] impsPaymentSuccess = {"0"};
        String[] impsPaymentError = {"1","2","3","4","5","6","7","8","9","10","12","13","14","15","16","18","19","20","21","22","23","24","32","34",
                "35","36","37","38","39","41","51","52","62","65","70","71","72","73","74","75","76","77","101","201","202","203","204","205","206",
                "207","208","403","901","902","903","904","905","915","916","917","918","919","920","921","922","923","924","68","50","29","49","U01",
                "U02","U03","U04","U06","U17","U28","U48","U49","U52","60","61","96","ZI"};
        String[] impsPaymentPending = {"11","30","31","33","40","63","80","102","814"};
        impsPaymentSuccessCodes = Arrays.asList(impsPaymentSuccess);
        impsPaymentErrorCodes = Arrays.asList(impsPaymentError);
        impsPaymentPendingCodes = Arrays.asList(impsPaymentPending);

        String[] impsStatusCheckSuccess = {"0"};
        String[] impsStatusCheckError = {"1","2","3","4","5","6","7","8","9","10","12","13","14","15","17","18","19","20","21","22","24","32","34","35",
                "36","37","38","39","41","51","52","62","65","67","70","71","72","73","74","75","76","77","201","202","203","204","205","206","207","208",
                "903","904","905","915","916","917","918","919","920","921","922","923","924","68","69","50","29","49","U01","U02","U03","U04","U06","U17",
                "U28","U48","U49","U52","60","61","96","ZI","804"};
        String[] impsStatusCheckPending = {"11","23","30","31","33","40","63","80","101","102","403","901","902","814","805"};
        impsStatusCheckSuccessCodes = Arrays.asList(impsStatusCheckSuccess);
        impsStatusCheckErrorCodes = Arrays.asList(impsStatusCheckError);
        impsStatusCheckPendingCodes = Arrays.asList(impsStatusCheckPending);

    }

    /*public PaymentSwitch(Map<String, String> paymentUrl) {

    }*/

    public Payment processPayment(Payment paymentInput) throws ProcessorException {
        Payment payment = paymentInput;
        PAYMENT_TYPE paymentType = payment.getPaymentType();
        ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);
        om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        om.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        switch (paymentType) {
            case IMPS:
                PaymentResponse impsPaymentResponse = processImpsPayment(payment.getPaymentRequest());
                if (impsPaymentResponse.getResponseCode() == 200) {
                    PaymentResponseIMPS paymentResponseIMPS = (PaymentResponseIMPS) impsPaymentResponse;
                    if (impsPaymentSuccessCodes.contains(paymentResponseIMPS.getActCode())) {
                        payment.setPaymentStatus(PAYMENT_STATUS.SUCCESS);
                    } else if (impsPaymentErrorCodes.contains(paymentResponseIMPS.getActCode())) {
                        payment.setPaymentStatus(PAYMENT_STATUS.FAILED);
                    } else if (impsPaymentPendingCodes.contains(paymentResponseIMPS.getActCode())) {
                        payment.setPaymentStatus(PAYMENT_STATUS.PENDING);
                        PaymentResponsePendingIMPS pendingImps = null;
                        try {
                            pendingImps = om.readValue(paymentResponseIMPS.getResponseBody(), PaymentResponsePendingIMPS.class);
                        } catch (JsonProcessingException e) {
                            throw new ProcessorException(e.getMessage());
                        }
                        pendingImps.setResponseCode(200);
                        pendingImps.setResponseBody(paymentResponseIMPS.getResponseBody());
                        impsPaymentResponse = pendingImps;
                    }
                    payment.setPaymentResponse(impsPaymentResponse);
                } else {
                    payment.setPaymentStatus(PAYMENT_STATUS.PENDING);
                    payment.setPaymentResponseFromSwitch(impsPaymentResponse);
                }
                break;
            case UPI:
                PaymentResponse paymentResponse = processUpiPayment(payment.getPaymentRequest());
                if (paymentResponse.getResponseCode() == 200) {
                    PaymentResponseUPI paymentResponseUPI = (PaymentResponseUPI) paymentResponse;
                    if (upiPaymentSuccessCodes.contains(paymentResponseUPI.getResponse())) {
                        payment.setPaymentStatus(PAYMENT_STATUS.SUCCESS);
                    } else if (upiPaymentErrorCodes.contains(paymentResponseUPI.getResponse())) {
                        payment.setPaymentStatus(PAYMENT_STATUS.FAILED);
                        PaymentResponseErrorUPI errorUpi = null;
                        try {
                            errorUpi = om.readValue(paymentResponseUPI.getResponseBody(), PaymentResponseErrorUPI.class);
                        } catch (JsonProcessingException e) {
                            throw new ProcessorException(e.getMessage());
                        }
                        errorUpi.setResponseCode(200);
                        errorUpi.setResponseBody(paymentResponseUPI.getResponseBody());
                        impsPaymentResponse = errorUpi;
                    } else if (upiPaymentPendingCodes.contains(paymentResponseUPI.getResponse())) {
                        payment.setPaymentStatus(PAYMENT_STATUS.PENDING);
                    }
                    payment.setPaymentResponse(paymentResponse);
                } else {
                    payment.setPaymentStatus(PAYMENT_STATUS.PENDING);
                    payment.setPaymentResponseFromSwitch(paymentResponse);
                }
                break;
            case NEFT:
                PaymentResponse neftPaymentResponse = processNeftPayment(payment.getPaymentRequest());
                if (neftPaymentResponse.getResponseCode() == 200) {
                    PaymentResponseNEFT paymentResponseNEFT = (PaymentResponseNEFT) neftPaymentResponse;
                    if(Objects.equals(paymentResponseNEFT.getResponse(), "SUCCESS") && Objects.equals(paymentResponseNEFT.getStatus(), "SUCCESS")) {
                        payment.setPaymentStatus(PAYMENT_STATUS.SUCCESS);
                    } else if (Objects.equals(paymentResponseNEFT.getStatus(), "PENDING")
                            || (!Objects.equals(paymentResponseNEFT.getResponse(), "SUCCESS") && !Objects.equals(paymentResponseNEFT.getResponse(), "FAILURE"))
                            || (Objects.equals(paymentResponseNEFT.getResponse(), "FAILURE") && Objects.equals(paymentResponseNEFT.getStatus(), "SUCCESS"))
                            || (Objects.equals(paymentResponseNEFT.getStatus(), "PENDING FOR PROCESSING"))) {
                        payment.setPaymentStatus(PAYMENT_STATUS.PENDING);
                    } else if(Objects.equals(paymentResponseNEFT.getStatus(), "FAILURE") || Objects.equals(paymentResponseNEFT.getStatus(), "DUPLICATE")) {
                        payment.setPaymentStatus(PAYMENT_STATUS.FAILED);
                        PaymentResponseErrorNEFT errorNEFT = null;
                        try {
                            errorNEFT = om.readValue(paymentResponseNEFT.getResponseBody(), PaymentResponseErrorNEFT.class);
                        } catch (JsonProcessingException e) {
                            throw new ProcessorException(e.getMessage());
                        }
                        errorNEFT.setResponseCode(200);
                        errorNEFT.setResponseBody(paymentResponseNEFT.getResponseBody());
                        neftPaymentResponse = errorNEFT;
                    }
                    payment.setPaymentResponse(neftPaymentResponse);
                } else {
                    payment.setPaymentStatus(PAYMENT_STATUS.PENDING);
                    payment.setPaymentResponseFromSwitch(neftPaymentResponse);
                }
                break;
            case RTGS:
                PaymentResponse rtgsPaymentResponse = processRtgsPayment(payment.getPaymentRequest());
                if (rtgsPaymentResponse.getResponseCode() == 200) {
                    PaymentResponseRTGS paymentResponseRTGS = (PaymentResponseRTGS) rtgsPaymentResponse;
                    if(Objects.equals(paymentResponseRTGS.getResponse(), "SUCCESS") && Objects.equals(paymentResponseRTGS.getStatus(), "SUCCESS")) {
                        payment.setPaymentStatus(PAYMENT_STATUS.SUCCESS);
                    } else if (Objects.equals(paymentResponseRTGS.getStatus(), "PENDING")
                            || (!Objects.equals(paymentResponseRTGS.getResponse(), "SUCCESS") && !Objects.equals(paymentResponseRTGS.getResponse(), "FAILURE"))
                            || (Objects.equals(paymentResponseRTGS.getResponse(), "FAILURE") && Objects.equals(paymentResponseRTGS.getStatus(), "SUCCESS"))
                            || (Objects.equals(paymentResponseRTGS.getStatus(), "PENDING FOR PROCESSING"))) {
                        payment.setPaymentStatus(PAYMENT_STATUS.PENDING);
                    } else if(Objects.equals(paymentResponseRTGS.getStatus(), "FAILURE") || Objects.equals(paymentResponseRTGS.getStatus(), "DUPLICATE")) {
                        payment.setPaymentStatus(PAYMENT_STATUS.FAILED);
                        PaymentResponseErrorRTGS errorRtgs = null;
                        try {
                            errorRtgs = om.readValue(paymentResponseRTGS.getResponseBody(), PaymentResponseErrorRTGS.class);
                        } catch (JsonProcessingException e) {
                            throw new ProcessorException(e.getMessage());
                        }
                        errorRtgs.setResponseCode(200);
                        errorRtgs.setResponseBody(paymentResponseRTGS.getResponseBody());
                        rtgsPaymentResponse = errorRtgs;
                    }
                    payment.setPaymentResponse(rtgsPaymentResponse);
                } else {
                    payment.setPaymentStatus(PAYMENT_STATUS.PENDING);
                    payment.setPaymentResponseFromSwitch(rtgsPaymentResponse);
                }
                break;
            case FT:
                PaymentResponse ftPaymentResponse = processFtPayment(payment.getPaymentRequest());
                if (ftPaymentResponse.getResponseCode() == 200) {
                    PaymentResponseFT paymentResponseFT = (PaymentResponseFT) ftPaymentResponse;
                    if(Objects.equals(paymentResponseFT.getResponse(), "SUCCESS") && Objects.equals(paymentResponseFT.getStatus(), "SUCCESS")) {
                        payment.setPaymentStatus(PAYMENT_STATUS.SUCCESS);
                    } else if (Objects.equals(paymentResponseFT.getStatus(), "PENDING")
                            || (!Objects.equals(paymentResponseFT.getResponse(), "SUCCESS") && !Objects.equals(paymentResponseFT.getResponse(), "FAILURE"))
                            || (Objects.equals(paymentResponseFT.getResponse(), "FAILURE") && Objects.equals(paymentResponseFT.getStatus(), "SUCCESS"))
                            || (Objects.equals(paymentResponseFT.getStatus(), "PENDING FOR PROCESSING"))) {
                        payment.setPaymentStatus(PAYMENT_STATUS.PENDING);
                    } else if(Objects.equals(paymentResponseFT.getStatus(), "FAILURE") || Objects.equals(paymentResponseFT.getStatus(), "DUPLICATE")) {
                        payment.setPaymentStatus(PAYMENT_STATUS.FAILED);
                        PaymentResponseErrorFT errorFT = null;
                        try {
                            errorFT = om.readValue(paymentResponseFT.getResponseBody(), PaymentResponseErrorFT.class);
                        } catch (JsonProcessingException e) {
                            throw new ProcessorException(e.getMessage());
                        }
                        errorFT.setResponseCode(200);
                        errorFT.setResponseBody(paymentResponseFT.getResponseBody());
                        ftPaymentResponse = errorFT;
                    }
                    payment.setPaymentResponse(ftPaymentResponse);
                } else {
                    payment.setPaymentStatus(PAYMENT_STATUS.PENDING);
                    payment.setPaymentResponseFromSwitch(ftPaymentResponse);
                }
                break;
            default:
                //
        }
        payment.setPaymentRespDateTime(new Date());
        return payment;
    }

    public Payment checkPaymentStatus(Payment paymentInput) throws ProcessorException {
        Payment payment = paymentInput;
        PAYMENT_TYPE paymentType = payment.getPaymentType();
        switch (paymentType) {
            case IMPS:
                PaymentStatusCheckResponse impsStatusCheckResponse = checkPaymentStatusImps(payment.getPaymentRetry().getPaymentStatusCheckRequest());
                PaymentRetry impsPaymentRetry = payment.getPaymentRetry();
                if (impsPaymentRetry == null) {
                    impsPaymentRetry = new PaymentRetry();
                }
                if (impsStatusCheckResponse.getResponseCode() == 200) {
                    ResponseStatusCheckIMPS statusResponseIMPS = (ResponseStatusCheckIMPS) impsStatusCheckResponse;
                    //statusResponseIMPS.setActCode("31");
                    if (impsStatusCheckSuccessCodes.contains(statusResponseIMPS.getActCode())) {
                        impsPaymentRetry.setLastStatusCheck(PAYMENT_STATUS.SUCCESS);
                    } else if (impsStatusCheckErrorCodes.contains(statusResponseIMPS.getActCode())) {
                        impsPaymentRetry.setLastStatusCheck(PAYMENT_STATUS.FAILED);
                    } else if(impsStatusCheckPendingCodes.contains(statusResponseIMPS.getActCode())) {
                        impsPaymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    }/* else if(statusResponseIMPS.getCheckStatusCode()=="17") { //15/U48 for UPI Failed for merchant callback else Pending
                        impsPaymentRetry.setLastStatusCheck(PAYMENT_STATUS.FAILED);
                    }*/ else if(statusResponseIMPS.getCheckStatusCode()!="0") {
                        impsPaymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    }
                    impsPaymentRetry.setPaymentStatusCheckResponse(statusResponseIMPS);
                    impsPaymentRetry.setLastRetryDatetime(new Date());
                    payment.setPaymentRetry(impsPaymentRetry);
                } else {
                    ResponseStatusCheckIMPS statusResponseIMPS = (ResponseStatusCheckIMPS) impsStatusCheckResponse;
                    impsPaymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    impsPaymentRetry.setPaymentStatusCheckResponse(statusResponseIMPS);
                    impsPaymentRetry.setLastRetryDatetime(new Date());
                    payment.setPaymentRetry(impsPaymentRetry);
                }
                break;
            case UPI:
                ResponseStatusCheckUPI statusCheckResponse = (ResponseStatusCheckUPI) checkPaymentStatusUpi(payment.getPaymentRetry()
                        .getPaymentStatusCheckRequest());
                PaymentRetry paymentRetry = payment.getPaymentRetry();
                if (paymentRetry == null) {
                    paymentRetry = new PaymentRetry();
                }
                if (statusCheckResponse.getResponseCode() == 200) {
                    ResponseStatusCheckUPI statusResponseUPI = (ResponseStatusCheckUPI) statusCheckResponse;
                    String respCode = "";
                    if(statusResponseUPI.getMobileAppData()!=null &&
                            statusResponseUPI.getMobileAppData().getOriginalTxnResponseCode()!=null &&
                            statusResponseUPI.getMobileAppData().getOriginalTxnResponseCode()!="") {
                        respCode = statusResponseUPI.getMobileAppData().getOriginalTxnResponseCode();
                    } else {
                        respCode = statusResponseUPI.getResponse();
                    }
                    if (respCode.equals("0")) {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.SUCCESS);
                    } else if (upiStatusCheckErrorCodes.contains(respCode)) {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.FAILED);
                    } else if (upiStatusCheckPendingCodes.contains(respCode)) {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    }
                    paymentRetry.setPaymentStatusCheckResponse(statusResponseUPI);
                    paymentRetry.setLastRetryDatetime(new Date());
                    payment.setPaymentRetry(paymentRetry);
                } else {
                    ResponseStatusCheckUPI statusResponseUPI = (ResponseStatusCheckUPI) statusCheckResponse;
                    paymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    paymentRetry.setPaymentStatusCheckResponse(statusResponseUPI);
                    paymentRetry.setLastRetryDatetime(new Date());
                    payment.setPaymentRetry(paymentRetry);
                }
                break;
            case NEFT:
                PaymentStatusCheckResponse neftStatusCheckResponse = checkPaymentStatusNeft(payment.getPaymentRetry().getPaymentStatusCheckRequest());
                PaymentRetry neftPaymentRetry = payment.getPaymentRetry();
                if (neftPaymentRetry == null) {
                    neftPaymentRetry = new PaymentRetry();
                }
                if (neftStatusCheckResponse.getResponseCode() == 200) {
                    ResponseStatusCheckNEFT statusResponseNEFT = (ResponseStatusCheckNEFT) neftStatusCheckResponse;
                    if(Objects.equals(statusResponseNEFT.getResponse(), "SUCCESS") && Objects.equals(statusResponseNEFT.getStatus(), "SUCCESS")) {
                        neftPaymentRetry.setLastStatusCheck(PAYMENT_STATUS.SUCCESS);
                    } else if (Objects.equals(statusResponseNEFT.getStatus(), "PENDING")
                            || (!Objects.equals(statusResponseNEFT.getResponse(), "SUCCESS"))
                            || (Objects.equals(statusResponseNEFT.getStatus(), "PENDING FOR PROCESSING"))
                            || Objects.equals(statusResponseNEFT.getStatus(), "SUSPECT")
                            || Objects.equals(statusResponseNEFT.getStatus(), "REJECTED")
                            || Objects.equals(statusResponseNEFT.getStatus(), "UNCERTAIN")) {
                        neftPaymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    } else if(Objects.equals(statusResponseNEFT.getStatus(), "FAILURE")
                            || Objects.equals(statusResponseNEFT.getStatus(), "UNKNOWN")
                            || Objects.equals(statusResponseNEFT.getStatus(), "RECALLED")
                            || Objects.equals(statusResponseNEFT.getStatus(), "REVERSED")) {
                        neftPaymentRetry.setLastStatusCheck(PAYMENT_STATUS.FAILED);
                    }
                    neftPaymentRetry.setPaymentStatusCheckResponse(statusResponseNEFT);
                    neftPaymentRetry.setLastRetryDatetime(new Date());
                    payment.setPaymentRetry(neftPaymentRetry);
                } else {
                    ResponseStatusCheckNEFT statusResponseNEFT = (ResponseStatusCheckNEFT) neftStatusCheckResponse;
                    neftPaymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    neftPaymentRetry.setPaymentStatusCheckResponse(statusResponseNEFT);
                    neftPaymentRetry.setLastRetryDatetime(new Date());
                    payment.setPaymentRetry(neftPaymentRetry);
                }
                break;
            case RTGS:
                PaymentStatusCheckResponse rtgsStatusCheckResponse = checkPaymentStatusRtgs(payment.getPaymentRetry().getPaymentStatusCheckRequest());
                PaymentRetry rtgsPaymentRetry = payment.getPaymentRetry();
                if (rtgsPaymentRetry == null) {
                    rtgsPaymentRetry = new PaymentRetry();
                }
                if (rtgsStatusCheckResponse.getResponseCode() == 200) {
                    ResponseStatusCheckRTGS statusResponseRTGS = (ResponseStatusCheckRTGS) rtgsStatusCheckResponse;
                    if(Objects.equals(statusResponseRTGS.getResponse(), "SUCCESS") && Objects.equals(statusResponseRTGS.getStatus(), "SUCCESS")) {
                        rtgsPaymentRetry.setLastStatusCheck(PAYMENT_STATUS.SUCCESS);
                    } else if (Objects.equals(statusResponseRTGS.getStatus(), "PENDING")
                            || (!Objects.equals(statusResponseRTGS.getResponse(), "SUCCESS"))
                            || (Objects.equals(statusResponseRTGS.getStatus(), "PENDING FOR PROCESSING"))
                            || Objects.equals(statusResponseRTGS.getStatus(), "SUSPECT")
                            || Objects.equals(statusResponseRTGS.getStatus(), "REJECTED")
                            || Objects.equals(statusResponseRTGS.getStatus(), "UNCERTAIN")) {
                        rtgsPaymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    } else if(Objects.equals(statusResponseRTGS.getStatus(), "FAILURE")
                            || Objects.equals(statusResponseRTGS.getStatus(), "UNKNOWN")
                            || Objects.equals(statusResponseRTGS.getStatus(), "RECALLED")
                            || Objects.equals(statusResponseRTGS.getStatus(), "REVERSED")) {
                        rtgsPaymentRetry.setLastStatusCheck(PAYMENT_STATUS.FAILED);
                    }
                    rtgsPaymentRetry.setPaymentStatusCheckResponse(statusResponseRTGS);
                    rtgsPaymentRetry.setLastRetryDatetime(new Date());
                    payment.setPaymentRetry(rtgsPaymentRetry);
                } else {
                    ResponseStatusCheckRTGS statusResponseRTGS = (ResponseStatusCheckRTGS) rtgsStatusCheckResponse;
                    rtgsPaymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    rtgsPaymentRetry.setPaymentStatusCheckResponse(statusResponseRTGS);
                    rtgsPaymentRetry.setLastRetryDatetime(new Date());
                    payment.setPaymentRetry(rtgsPaymentRetry);
                }
                break;
            case FT:
                PaymentStatusCheckResponse ftStatusCheckResponse = checkPaymentStatusFt(payment.getPaymentRetry().getPaymentStatusCheckRequest());
                PaymentRetry ftPaymentRetry = payment.getPaymentRetry();
                if (ftPaymentRetry == null) {
                    ftPaymentRetry = new PaymentRetry();
                }
                if (ftStatusCheckResponse.getResponseCode() == 200) {
                    ResponseStatusCheckFT statusResponseFT = (ResponseStatusCheckFT) ftStatusCheckResponse;
                    if(Objects.equals(statusResponseFT.getResponse(), "SUCCESS") && Objects.equals(statusResponseFT.getStatus(), "SUCCESS")) {
                        ftPaymentRetry.setLastStatusCheck(PAYMENT_STATUS.SUCCESS);
                    } else if (Objects.equals(statusResponseFT.getStatus(), "PENDING")
                            || (!Objects.equals(statusResponseFT.getResponse(), "SUCCESS"))
                            || (Objects.equals(statusResponseFT.getStatus(), "PENDING FOR PROCESSING"))
                            || Objects.equals(statusResponseFT.getStatus(), "SUSPECT")
                            || Objects.equals(statusResponseFT.getStatus(), "REJECTED")
                            || Objects.equals(statusResponseFT.getStatus(), "UNCERTAIN")) {
                        ftPaymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    } else if(Objects.equals(statusResponseFT.getStatus(), "FAILURE")
                            || Objects.equals(statusResponseFT.getStatus(), "UNKNOWN")
                            || Objects.equals(statusResponseFT.getStatus(), "RECALLED")
                            || Objects.equals(statusResponseFT.getStatus(), "REVERSED")) {
                        ftPaymentRetry.setLastStatusCheck(PAYMENT_STATUS.FAILED);
                    }
                    ftPaymentRetry.setPaymentStatusCheckResponse(statusResponseFT);
                    ftPaymentRetry.setLastRetryDatetime(new Date());
                    payment.setPaymentRetry(ftPaymentRetry);
                } else {
                    ResponseStatusCheckFT statusResponseFT = (ResponseStatusCheckFT) ftStatusCheckResponse;
                    ftPaymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    ftPaymentRetry.setPaymentStatusCheckResponse(statusResponseFT);
                    ftPaymentRetry.setLastRetryDatetime(new Date());
                    payment.setPaymentRetry(ftPaymentRetry);
                }
                break;
            default:
                //
        }
        return payment;
    }

    public PaymentRetry checkPaymentStatus(String statusCheckReqString, PAYMENT_TYPE paymentType) throws ProcessorException {
        ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);
        om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        om.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        PaymentRetry paymentRetry = new PaymentRetry();
        paymentRetry.setStatusCheckReqString(statusCheckReqString);
        switch (paymentType) {
            case IMPS:
                RequestStatusCheckIMPS statusCheckReqImps = null;
                try {
                    statusCheckReqImps = om.readValue(statusCheckReqString, RequestStatusCheckIMPS.class);
                } catch (JsonProcessingException e) {
                    e.printStackTrace();
                    throw new ProcessorException(e.getMessage());
                }
                PaymentStatusCheckResponse impsStatusCheckResponse = checkPaymentStatusImps(statusCheckReqImps);
                if (impsStatusCheckResponse.getResponseCode() == 200) {
                    ResponseStatusCheckIMPS statusResponseIMPS = (ResponseStatusCheckIMPS) impsStatusCheckResponse;
                    if(statusResponseIMPS.getActCode()=="17") {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.FAILED);
                    } else if (impsStatusCheckSuccessCodes.contains(statusResponseIMPS.getActCode())) {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.SUCCESS);
                    } else if (impsStatusCheckErrorCodes.contains(statusResponseIMPS.getActCode())) {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.FAILED);
                    } else if(impsStatusCheckPendingCodes.contains(statusResponseIMPS.getActCode())) {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    } else if(statusResponseIMPS.getActCode()=="17") {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.FAILED);
                    } else if(statusResponseIMPS.getCheckStatusCode()!="0") {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    }
                    paymentRetry.setPaymentStatusCheckResponse(statusResponseIMPS);
                    paymentRetry.setLastRetryDatetime(new Date());
                } else {
                    ResponseStatusCheckIMPS statusResponseIMPS = (ResponseStatusCheckIMPS) impsStatusCheckResponse;
                    paymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    paymentRetry.setPaymentStatusCheckResponse(statusResponseIMPS);
                    paymentRetry.setLastRetryDatetime(new Date());
                }
                break;
            case UPI:
                RequestStatusCheckUPI statusCheckReqUpi = null;
                try {
                    statusCheckReqUpi = om.readValue(statusCheckReqString, RequestStatusCheckUPI.class);
                    String tempSeqNum = statusCheckReqUpi.getSeqNo();
                    String tempUUID = UUID.randomUUID().toString().replace("-", "");
                    String seqNum = "";
                    if(tempSeqNum!=null && tempSeqNum.length()>0) {
                        seqNum = tempSeqNum.substring(0, tempSeqNum.length()/2);
                        seqNum = seqNum + tempUUID.substring(0, tempUUID.length()/2);
                    } else{
                        seqNum = tempUUID;
                    }
                    if(seqNum.length()>30){
                        seqNum = seqNum.substring(0, 29);
                    }
                    statusCheckReqUpi.setSeqNo(seqNum);
                } catch (JsonProcessingException e) {
                    e.printStackTrace();
                    throw new ProcessorException(e.getMessage());
                }
                try {
                    paymentRetry.setStatusCheckReqString(om.writeValueAsString(statusCheckReqUpi));
                } catch (JsonProcessingException e) {
                    e.printStackTrace();
                    throw new ProcessorException(e.getMessage());
                }
                PaymentStatusCheckResponse statusCheckResponse = checkPaymentStatusUpi(statusCheckReqUpi);
                if (statusCheckResponse.getResponseCode() == 200) {
                    ResponseStatusCheckUPI statusResponseUPI = (ResponseStatusCheckUPI) statusCheckResponse;
                    String respCode = "";
                    if(statusResponseUPI.getMobileAppData()!=null &&
                            statusResponseUPI.getMobileAppData().getOriginalTxnResponseCode()!=null &&
                            statusResponseUPI.getMobileAppData().getOriginalTxnResponseCode()!="") {
                        respCode = statusResponseUPI.getMobileAppData().getOriginalTxnResponseCode();
                    } else {
                        respCode = statusResponseUPI.getResponse();
                    }
                    if(respCode=="15" || respCode=="U48") { //15/U48 for UPI Failed for merchant callback else Pending
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.FAILED);
                    } else if (upiStatusCheckSuccessCodes.contains(respCode)) {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.SUCCESS);
                    } else if (upiStatusCheckErrorCodes.contains(respCode)) {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.FAILED);
                    } else if (upiStatusCheckPendingCodes.contains(respCode)) {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    }
                    paymentRetry.setPaymentStatusCheckResponse(statusResponseUPI);
                    paymentRetry.setLastRetryDatetime(new Date());
                } else {
                    ResponseStatusCheckUPI statusResponseUPI = (ResponseStatusCheckUPI) statusCheckResponse;
                    paymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    paymentRetry.setPaymentStatusCheckResponse(statusResponseUPI);
                    paymentRetry.setLastRetryDatetime(new Date());
                }
                break;
            case NEFT:
                RequestStatusCheckNEFT statusCheckReqNeft = null;
                try {
                    statusCheckReqNeft = om.readValue(statusCheckReqString, RequestStatusCheckNEFT.class);
                } catch (JsonProcessingException e) {
                    e.printStackTrace();
                    throw new ProcessorException(e.getMessage());
                }
                PaymentStatusCheckResponse neftStatusCheckResponse = checkPaymentStatusNeft(statusCheckReqNeft);
                if (neftStatusCheckResponse.getResponseCode() == 200) {
                    ResponseStatusCheckNEFT statusResponseNEFT = (ResponseStatusCheckNEFT) neftStatusCheckResponse;
                    if(Objects.equals(statusResponseNEFT.getResponse(), "SUCCESS") && Objects.equals(statusResponseNEFT.getStatus(), "SUCCESS")) {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.SUCCESS);
                    } else if (Objects.equals(statusResponseNEFT.getStatus(), "PENDING")
                            || (!Objects.equals(statusResponseNEFT.getResponse(), "SUCCESS"))
                            || (Objects.equals(statusResponseNEFT.getStatus(), "PENDING FOR PROCESSING"))
                            || Objects.equals(statusResponseNEFT.getStatus(), "SUSPECT")
                            || Objects.equals(statusResponseNEFT.getStatus(), "REJECTED")
                            || Objects.equals(statusResponseNEFT.getStatus(), "UNCERTAIN")) {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    } else if(Objects.equals(statusResponseNEFT.getStatus(), "FAILURE")
                            || Objects.equals(statusResponseNEFT.getStatus(), "UNKNOWN")
                            || Objects.equals(statusResponseNEFT.getStatus(), "RECALLED")
                            || Objects.equals(statusResponseNEFT.getStatus(), "REVERSED")) {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.FAILED);
                    }
                    paymentRetry.setPaymentStatusCheckResponse(statusResponseNEFT);
                    paymentRetry.setLastRetryDatetime(new Date());
                } else {
                    ResponseStatusCheckNEFT statusResponseNEFT = (ResponseStatusCheckNEFT) neftStatusCheckResponse;
                    paymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    paymentRetry.setPaymentStatusCheckResponse(statusResponseNEFT);
                    paymentRetry.setLastRetryDatetime(new Date());
                }
                break;
            case RTGS:
                RequestStatusCheckRTGS statusCheckReqRtgs = null;
                try {
                    statusCheckReqRtgs = om.readValue(statusCheckReqString, RequestStatusCheckRTGS.class);
                } catch (JsonProcessingException e) {
                    e.printStackTrace();
                    throw new ProcessorException(e.getMessage());
                }
                PaymentStatusCheckResponse rtgsStatusCheckResponse = checkPaymentStatusRtgs(statusCheckReqRtgs);
                if (rtgsStatusCheckResponse.getResponseCode() == 200) {
                    ResponseStatusCheckRTGS statusResponseRTGS = (ResponseStatusCheckRTGS) rtgsStatusCheckResponse;
                    if(Objects.equals(statusResponseRTGS.getResponse(), "SUCCESS") && Objects.equals(statusResponseRTGS.getStatus(), "SUCCESS")) {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.SUCCESS);
                    } else if (Objects.equals(statusResponseRTGS.getStatus(), "PENDING")
                            || (!Objects.equals(statusResponseRTGS.getResponse(), "SUCCESS"))
                            || (Objects.equals(statusResponseRTGS.getStatus(), "PENDING FOR PROCESSING"))
                            || Objects.equals(statusResponseRTGS.getStatus(), "SUSPECT")
                            || Objects.equals(statusResponseRTGS.getStatus(), "REJECTED")
                            || Objects.equals(statusResponseRTGS.getStatus(), "UNCERTAIN")) {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    } else if(Objects.equals(statusResponseRTGS.getStatus(), "FAILURE")
                            || Objects.equals(statusResponseRTGS.getStatus(), "UNKNOWN")
                            || Objects.equals(statusResponseRTGS.getStatus(), "RECALLED")
                            || Objects.equals(statusResponseRTGS.getStatus(), "REVERSED")) {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.FAILED);
                    }
                    paymentRetry.setPaymentStatusCheckResponse(statusResponseRTGS);
                    paymentRetry.setLastRetryDatetime(new Date());
                } else {
                    ResponseStatusCheckRTGS statusResponseRTGS = (ResponseStatusCheckRTGS) rtgsStatusCheckResponse;
                    paymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    paymentRetry.setPaymentStatusCheckResponse(statusResponseRTGS);
                    paymentRetry.setLastRetryDatetime(new Date());
                }
                break;
            case FT:
                RequestStatusCheckFT statusCheckReqFt = null;
                try {
                    statusCheckReqFt = om.readValue(statusCheckReqString, RequestStatusCheckFT.class);
                } catch (JsonProcessingException e) {
                    e.printStackTrace();
                    throw new ProcessorException(e.getMessage());
                }
                PaymentStatusCheckResponse ftStatusCheckResponse = checkPaymentStatusFt(statusCheckReqFt);
                if (ftStatusCheckResponse.getResponseCode() == 200) {
                    ResponseStatusCheckFT statusResponseFT = (ResponseStatusCheckFT) ftStatusCheckResponse;
                    if(Objects.equals(statusResponseFT.getResponse(), "SUCCESS") && Objects.equals(statusResponseFT.getStatus(), "SUCCESS")) {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.SUCCESS);
                    } else if (Objects.equals(statusResponseFT.getStatus(), "PENDING")
                            || (!Objects.equals(statusResponseFT.getResponse(), "SUCCESS"))
                            || (Objects.equals(statusResponseFT.getStatus(), "PENDING FOR PROCESSING"))
                            || Objects.equals(statusResponseFT.getStatus(), "SUSPECT")
                            || Objects.equals(statusResponseFT.getStatus(), "REJECTED")
                            || Objects.equals(statusResponseFT.getStatus(), "UNCERTAIN")) {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    } else if(Objects.equals(statusResponseFT.getStatus(), "FAILURE")
                            || Objects.equals(statusResponseFT.getStatus(), "UNKNOWN")
                            || Objects.equals(statusResponseFT.getStatus(), "RECALLED")
                            || Objects.equals(statusResponseFT.getStatus(), "REVERSED")) {
                        paymentRetry.setLastStatusCheck(PAYMENT_STATUS.FAILED);
                    }
                    paymentRetry.setPaymentStatusCheckResponse(statusResponseFT);
                    paymentRetry.setLastRetryDatetime(new Date());
                } else {
                    ResponseStatusCheckFT statusResponseFT = (ResponseStatusCheckFT) ftStatusCheckResponse;
                    paymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                    paymentRetry.setPaymentStatusCheckResponse(statusResponseFT);
                    paymentRetry.setLastRetryDatetime(new Date());
                }
                break;
            default:
                //
        }
        return paymentRetry;
    }

    public PaymentResponse processUpiPayment(PaymentRequest pmtRequest) throws ProcessorException {
        PaymentResponse upiResponse = null;
        ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);
        om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        om.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        PaymentRequestUPI upi = (PaymentRequestUPI) pmtRequest;
        String jsonStringReq = null;
        try {
            jsonStringReq = om.writeValueAsString(upi);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        String paymentResponseString = "";
        int responseCode = 0;
        //HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        List<String> responseList = postRequest(paymentUpiUrl, jsonStringReq);
        //paymentResponseString = response.body();
        responseCode = Integer.parseInt(responseList.get(0));
        paymentResponseString = responseList.get(1);
        try {
            if (responseCode == 404) {
                //Not Found
                PaymentResponseUPI transactionUPI = new PaymentResponseUPI();
                transactionUPI.setResponseBody(paymentResponseString);
                transactionUPI.setResponseCode(404);
                upiResponse = transactionUPI;
            } else if (responseCode == 200) {
                PaymentResponseUPI transactionUPI = om.readValue(paymentResponseString, PaymentResponseUPI.class);
                transactionUPI.setResponseBody(paymentResponseString);
                transactionUPI.setResponseCode(200);
                upiResponse = transactionUPI;
            } else if (responseCode >= 500) {
                BadGateway badGateway = new BadGateway();
                badGateway.setResponseBody(paymentResponseString);
                badGateway.setResponseCode(500);
                upiResponse = badGateway;
            }
        } catch (JsonProcessingException e) {
            throw new ProcessorException(e.getMessage());
        }
        return upiResponse;
    }

    public PaymentStatusCheckResponse checkPaymentStatusUpi(PaymentStatusCheckRequest pmtRequest) throws ProcessorException {
        PaymentStatusCheckResponse upiStatusResponse = null;
        RequestStatusCheckUPI upi = (RequestStatusCheckUPI) pmtRequest;
        ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);
        om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        om.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        String jsonStringReq = null;
        try {
            jsonStringReq = om.writeValueAsString(upi);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        String statusCheckResponseString = "";
        int responseCode = 0;
        List<String> responseList = postRequest(paymentUpiStatusUrl, jsonStringReq);
        responseCode = Integer.parseInt(responseList.get(0));
        statusCheckResponseString = responseList.get(1);
        try {
            if (responseCode == 404) {
                //Not Found
                ResponseStatusCheckUPI transactionUPI = new ResponseStatusCheckUPI();
                transactionUPI.setResponseBody(statusCheckResponseString);
                transactionUPI.setResponseCode(404);
                upiStatusResponse = transactionUPI;
            } else if (responseCode == 200) {
                /*if(statusCheckResponseString.equals("Transaction Processing Timeout")) {
                    ResponseStatusCheckUPI transactionUPI = new ResponseStatusCheckUPI();
                    transactionUPI.setResponseBody(statusCheckResponseString);
                    transactionUPI.setResponseCode(200);
                    upiStatusResponse = transactionUPI;
                } else {*/
                ResponseStatusCheckUPI transactionUPI = om.readValue(statusCheckResponseString, ResponseStatusCheckUPI.class);
                transactionUPI.setResponseBody(statusCheckResponseString);
                transactionUPI.setResponseCode(200);
                upiStatusResponse = transactionUPI;
                //}
            } else if (responseCode == 500) {
                //PaymentResponseErrorUPI errorUPI = om.readValue(statusCheckResponseString, PaymentResponseErrorUPI.class);
                ResponseStatusCheckUPI errorUPI = new ResponseStatusCheckUPI();
                errorUPI.setResponseBody(statusCheckResponseString);
                errorUPI.setResponseCode(500);
                upiStatusResponse = errorUPI;
            }
        } catch (JsonProcessingException e) {
            throw new ProcessorException(e.getMessage());
        }
        return upiStatusResponse;
    }

    public PaymentResponse processImpsPayment(PaymentRequest pmtRequest) throws ProcessorException {
        PaymentResponse impsResponse = null;
        ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);
        om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        om.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        PaymentRequestIMPS imps = (PaymentRequestIMPS) pmtRequest;
        String jsonStringReq = null;
        try {
            jsonStringReq = om.writeValueAsString(imps);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        String paymentResponseString = "";
        int responseCode = 0;
        //HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        List<String> responseList = postRequest(paymentImpsUrl, jsonStringReq);
        //paymentResponseString = response.body();
        responseCode = Integer.parseInt(responseList.get(0));
        paymentResponseString = responseList.get(1);
        try {
            if (responseCode == 404) {
                //Not Found
                PaymentResponseIMPS transactionIMPS = new PaymentResponseIMPS();
                transactionIMPS.setResponseBody(paymentResponseString);
                transactionIMPS.setResponseCode(404);
                impsResponse = transactionIMPS;
            } else if (responseCode == 200) {
                PaymentResponseIMPS transactionIMPS = om.readValue(paymentResponseString, PaymentResponseIMPS.class);
                transactionIMPS.setResponseBody(paymentResponseString);
                transactionIMPS.setResponseCode(200);
                impsResponse = transactionIMPS;
            } else if (responseCode >= 500) {
                //PaymentResponseErrorUPI errorUPI = om.readValue(paymentResponseString, PaymentResponseErrorUPI.class);
                BadGateway badGateway = new BadGateway();
                badGateway.setResponseBody(paymentResponseString);
                badGateway.setResponseCode(500);
                impsResponse = badGateway;
            }
        } catch (JsonProcessingException e) {
            throw new ProcessorException(e.getMessage());
        }
        return impsResponse;
    }

    public PaymentResponse processRtgsPayment(PaymentRequest pmtRequest) throws ProcessorException {
        PaymentResponse rtgsResponse = null;
        ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);
        om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        om.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        PaymentRequestRTGS rtgs = (PaymentRequestRTGS) pmtRequest;
        String jsonStringReq = null;
        try {
            jsonStringReq = om.writeValueAsString(rtgs);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        String paymentResponseString = "";
        int responseCode = 0;
        //HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        List<String> responseList = postRequest(paymentRtgsUrl, jsonStringReq);
        //paymentResponseString = response.body();
        responseCode = Integer.parseInt(responseList.get(0));
        paymentResponseString = responseList.get(1);
        try {
            if (responseCode == 404) {
                //Not Found
                PaymentResponseRTGS transactionRTGS = new PaymentResponseRTGS();
                transactionRTGS.setResponseBody(paymentResponseString);
                transactionRTGS.setResponseCode(404);
                rtgsResponse = transactionRTGS;
            } else if (responseCode == 200) {
                PaymentResponseRTGS transactionRTGS = om.readValue(paymentResponseString, PaymentResponseRTGS.class);
                transactionRTGS.setResponseBody(paymentResponseString);
                transactionRTGS.setResponseCode(200);
                rtgsResponse = transactionRTGS;
            } else if (responseCode >= 500) {
                BadGateway badGateway = new BadGateway();
                badGateway.setResponseBody(paymentResponseString);
                badGateway.setResponseCode(500);
                rtgsResponse = badGateway;
            }
        } catch (JsonProcessingException e) {
            throw new ProcessorException(e.getMessage());
        }
        return rtgsResponse;
    }

    public PaymentResponse processNeftPayment(PaymentRequest pmtRequest) throws ProcessorException {
        PaymentResponse neftResponse = null;

        ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);
        om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        om.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        PaymentRequestNEFT neft = (PaymentRequestNEFT) pmtRequest;
        String jsonStringReq = null;
        try {
            jsonStringReq = om.writeValueAsString(neft);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        String paymentResponseString = "";
        int responseCode = 0;
        List<String> responseList = postRequest(paymentNeftUrl, jsonStringReq);
        responseCode = Integer.parseInt(responseList.get(0));
        paymentResponseString = responseList.get(1);
        try {
            if (responseCode == 404) {
                //Not Found
                PaymentResponseNEFT transactionNEFT = new PaymentResponseNEFT();
                transactionNEFT.setResponseBody(paymentResponseString);
                transactionNEFT.setResponseCode(404);
                neftResponse = transactionNEFT;
            } else if (responseCode == 200) {
                PaymentResponseNEFT transactionNEFT = om.readValue(paymentResponseString, PaymentResponseNEFT.class);
                transactionNEFT.setResponseBody(paymentResponseString);
                transactionNEFT.setResponseCode(200);
                neftResponse = transactionNEFT;
            } else if (responseCode >= 500) {
                BadGateway badGateway = new BadGateway();
                badGateway.setResponseBody(paymentResponseString);
                badGateway.setResponseCode(500);
                neftResponse = badGateway;
            }
        } catch (JsonProcessingException e) {
            throw new ProcessorException(e.getMessage());
        }
        return neftResponse;
    }

    public PaymentStatusCheckResponse checkPaymentStatusImps(PaymentStatusCheckRequest pmtRequest) throws ProcessorException {
        PaymentStatusCheckResponse impsStatusResponse = null;
        RequestStatusCheckIMPS imps = (RequestStatusCheckIMPS) pmtRequest;
        //HttpClient client = HttpClient.newHttpClient();
        ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);
        om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        om.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);

        String jsonStringReq = null;
        try {
            jsonStringReq = om.writeValueAsString(imps);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
        String statusCheckResponseString = "";
        int responseCode = 0;
        List<String> responseList = postRequest(paymentImpsStatusUrl, jsonStringReq);
        //paymentResponseString = response.body();
        responseCode = Integer.parseInt(responseList.get(0));
        statusCheckResponseString = responseList.get(1);
        try {
            if (responseCode == 404 || responseCode == 403) {
                //Not Found //Access Error
                ResponseStatusCheckIMPS transactionIMPS = new ResponseStatusCheckIMPS();
                transactionIMPS.setResponseBody(statusCheckResponseString);
                transactionIMPS.setResponseCode(responseCode);
                impsStatusResponse = transactionIMPS;
            } else if (responseCode == 200) {
                ResponseStatusCheckIMPS transactionIMPS = om.readValue(statusCheckResponseString, ResponseStatusCheckIMPS.class);
                transactionIMPS.setResponseBody(statusCheckResponseString);
                transactionIMPS.setResponseCode(200);
                impsStatusResponse = transactionIMPS;
            } else if (responseCode == 500) {
                //PaymentResponseErrorUPI errorUPI = om.readValue(statusCheckResponseString, PaymentResponseErrorUPI.class);
                ResponseStatusCheckIMPS errorIMPS = new ResponseStatusCheckIMPS();
                errorIMPS.setResponseBody(statusCheckResponseString);
                errorIMPS.setResponseCode(500);
                impsStatusResponse = errorIMPS;
            }
        } catch (JsonProcessingException e) {
            throw new ProcessorException(e.getMessage());
        }
        return impsStatusResponse;
    }

    public PaymentStatusCheckResponse checkPaymentStatusNeft(PaymentStatusCheckRequest pmtRequest) throws ProcessorException {
        PaymentStatusCheckResponse neftStatusResponse = null;
        RequestStatusCheckNEFT neft = (RequestStatusCheckNEFT) pmtRequest;
        HttpClient client = HttpClient.newHttpClient();
        ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);
        om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        om.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);

        String jsonStringReq = null;
        try {
            jsonStringReq = om.writeValueAsString(neft);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        String statusCheckResponseString = "";
        int responseCode = 0;
        List<String> responseList = postRequest(paymentNeftStatusUrl, jsonStringReq);
        //paymentResponseString = response.body();
        responseCode = Integer.parseInt(responseList.get(0));
        statusCheckResponseString = responseList.get(1);
        try {
            if (responseCode == 404) {
                //Not Found
                ResponseStatusCheckNEFT transactionNEFT = new ResponseStatusCheckNEFT();
                transactionNEFT.setResponseBody(statusCheckResponseString);
                transactionNEFT.setResponseCode(404);
                neftStatusResponse = transactionNEFT;
            } else if (responseCode == 200) {
                ResponseStatusCheckNEFT transactionNEFT = om.readValue(statusCheckResponseString, ResponseStatusCheckNEFT.class);
                transactionNEFT.setResponseBody(statusCheckResponseString);
                transactionNEFT.setResponseCode(200);
                neftStatusResponse = transactionNEFT;
            } else if (responseCode == 500) {
                //PaymentResponseErrorUPI errorUPI = om.readValue(statusCheckResponseString, PaymentResponseErrorUPI.class);
                ResponseStatusCheckNEFT errorNEFT = new ResponseStatusCheckNEFT();
                errorNEFT.setResponseBody(statusCheckResponseString);
                errorNEFT.setResponseCode(500);
                neftStatusResponse = errorNEFT;
            }
        } catch (JsonProcessingException e) {
            throw new ProcessorException(e.getMessage());
        }
        return neftStatusResponse;
    }

    public PaymentStatusCheckResponse checkPaymentStatusRtgs(PaymentStatusCheckRequest pmtRequest) throws ProcessorException {
        PaymentStatusCheckResponse rtgsStatusResponse = null;
        RequestStatusCheckRTGS rtgs = (RequestStatusCheckRTGS) pmtRequest;
        HttpClient client = HttpClient.newHttpClient();
        ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);
        om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        om.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);

        String jsonStringReq = null;
        try {
            jsonStringReq = om.writeValueAsString(rtgs);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        String statusCheckResponseString = "";
        int responseCode = 0;
        List<String> responseList = postRequest(paymentRtgsStatusUrl, jsonStringReq);
        //paymentResponseString = response.body();
        responseCode = Integer.parseInt(responseList.get(0));
        statusCheckResponseString = responseList.get(1);
        try {
            if (responseCode == 404) {
                //Not Found
                ResponseStatusCheckRTGS transactionRTGS = new ResponseStatusCheckRTGS();
                transactionRTGS.setResponseBody(statusCheckResponseString);
                transactionRTGS.setResponseCode(404);
                rtgsStatusResponse = transactionRTGS;
            } else if (responseCode == 200) {
                ResponseStatusCheckRTGS transactionRTGS = om.readValue(statusCheckResponseString, ResponseStatusCheckRTGS.class);
                transactionRTGS.setResponseBody(statusCheckResponseString);
                transactionRTGS.setResponseCode(200);
                rtgsStatusResponse = transactionRTGS;
            } else if (responseCode == 500) {
                //PaymentResponseErrorUPI errorUPI = om.readValue(statusCheckResponseString, PaymentResponseErrorUPI.class);
                ResponseStatusCheckRTGS errorRTGS = new ResponseStatusCheckRTGS();
                errorRTGS.setResponseBody(statusCheckResponseString);
                errorRTGS.setResponseCode(500);
                rtgsStatusResponse = errorRTGS;
            }
        } catch (JsonProcessingException e) {
            throw new ProcessorException(e.getMessage());
        }
        return rtgsStatusResponse;
    }

    public PaymentResponse processFtPayment(PaymentRequest pmtRequest) throws ProcessorException {
        PaymentResponse ftResponse = null;
        ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);
        om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        om.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        PaymentRequestFT ft = (PaymentRequestFT) pmtRequest;
        String jsonStringReq = null;
        try {
            jsonStringReq = om.writeValueAsString(ft);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        String paymentResponseString = "";
        int responseCode = 0;
        //HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        List<String> responseList = postRequest(paymentFtUrl, jsonStringReq);
        //paymentResponseString = response.body();
        responseCode = Integer.parseInt(responseList.get(0));
        paymentResponseString = responseList.get(1);
        try {
            if (responseCode == 404) {
                //Not Found
                PaymentResponseFT transactionFT = new PaymentResponseFT();
                transactionFT.setResponseBody(paymentResponseString);
                transactionFT.setResponseCode(404);
                ftResponse = transactionFT;
            } else if (responseCode == 200) {
                PaymentResponseFT transactionFT = om.readValue(paymentResponseString, PaymentResponseFT.class);
                transactionFT.setResponseBody(paymentResponseString);
                transactionFT.setResponseCode(200);
                ftResponse = transactionFT;
            } else if (responseCode >= 500) {
                BadGateway badGateway = new BadGateway();
                badGateway.setResponseBody(paymentResponseString);
                badGateway.setResponseCode(500);
                ftResponse = badGateway;
            }
        } catch (JsonProcessingException e) {
            throw new ProcessorException(e.getMessage());
        }
        return ftResponse;
    }

    public PaymentStatusCheckResponse checkPaymentStatusFt(PaymentStatusCheckRequest pmtRequest) throws ProcessorException {
        PaymentStatusCheckResponse ftStatusResponse = null;
        RequestStatusCheckFT ft = (RequestStatusCheckFT) pmtRequest;
        // HttpClient client = HttpClient.newHttpClient();
        ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);
        om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        om.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);

        String jsonStringReq = null;
        try {
            jsonStringReq = om.writeValueAsString(ft);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        String statusCheckResponseString = "";
        int responseCode = 0;
        List<String> responseList = postRequest(paymentFtStatusUrl, jsonStringReq);
        //paymentResponseString = response.body();
        responseCode = Integer.parseInt(responseList.get(0));
        statusCheckResponseString = responseList.get(1);
        try {
            if (responseCode == 404) {
                //Not Found
                ResponseStatusCheckFT transactionFT = new ResponseStatusCheckFT();
                transactionFT.setResponseBody(statusCheckResponseString);
                transactionFT.setResponseCode(404);
                ftStatusResponse = transactionFT;
            } else if (responseCode == 200) {
                ResponseStatusCheckFT transactionFT = om.readValue(statusCheckResponseString, ResponseStatusCheckFT.class);
                transactionFT.setResponseBody(statusCheckResponseString);
                transactionFT.setResponseCode(200);
                ftStatusResponse = transactionFT;
            } else if (responseCode == 500) {
                //PaymentResponseErrorUPI errorUPI = om.readValue(statusCheckResponseString, PaymentResponseErrorUPI.class);
                ResponseStatusCheckFT errorFT = new ResponseStatusCheckFT();
                errorFT.setResponseBody(statusCheckResponseString);
                errorFT.setResponseCode(500);
                ftStatusResponse = errorFT;
            }
        } catch (JsonProcessingException e) {
            throw new ProcessorException(e.getMessage());
        }
        return ftStatusResponse;
    }

    private List<String> postRequest(String postUrl, String reqBodyAsString) throws ProcessorException {
        List<String> responseList =  new ArrayList<>();
        OkHttpClient httpClient = new OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS)
                .writeTimeout(50, TimeUnit.SECONDS).readTimeout(50, TimeUnit.SECONDS)
                .build();
        RequestBody body = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), reqBodyAsString);
        Request request = new Request.Builder()
                .url(postUrl)
                .post(body)
                .build();
        try (Response response = httpClient.newCall(request).execute()) {
            // Get response body
            String paymentResponseString = response.body().string();
            String responseCode = "" + response.code();
            responseList.add(responseCode);
            responseList.add(paymentResponseString);
        } catch (IOException e) {
            e.printStackTrace();
            String paymentResponseString = e.getMessage();
            String responseCode = "" + 500;
            responseList.add(responseCode);
            responseList.add(paymentResponseString);
        } finally {
            return responseList;
        }
    }

    private List<String> postDummyRequest(String postUrl, String reqBodyAsString) throws ProcessorException {
        throw new ProcessorException("Dummy Error");
    }

}