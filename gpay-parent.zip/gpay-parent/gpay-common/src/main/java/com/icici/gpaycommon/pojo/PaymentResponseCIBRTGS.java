package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PaymentResponseCIBRTGS{

    @JsonProperty("REQID")
    private String reqid;
    @JsonProperty("STATUS")
    private String status;
    @JsonProperty("UNIQUEID")
    private String uniqueid;
    @JsonProperty("URN")
    private String urn;
    @JsonProperty("UTRNUMBER")
    private String utrnumber;
    @JsonProperty("RESPONSE")
    private String response;

    /**
     * No args constructor for use in serialization
     *
     */
    public PaymentResponseCIBRTGS() {
    }

    public PaymentResponseCIBRTGS(String reqid, String status, String uniqueid, String urn, String utrnumber, String response) {
        super();
        this.reqid = reqid;
        this.status = status;
        this.uniqueid = uniqueid;
        this.urn = urn;
        this.utrnumber = utrnumber;
        this.response = response;
    }

    @JsonProperty("REQID")
    public String getReqid() {
        return reqid;
    }

    @JsonProperty("REQID")
    public void setReqid(String reqid) {
        this.reqid = reqid;
    }

    @JsonProperty("STATUS")
    public String getStatus() {
        return status;
    }

    @JsonProperty("STATUS")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("UNIQUEID")
    public String getUniqueid() {
        return uniqueid;
    }

    @JsonProperty("UNIQUEID")
    public void setUniqueid(String uniqueid) {
        this.uniqueid = uniqueid;
    }

    @JsonProperty("URN")
    public String getUrn() {
        return urn;
    }

    @JsonProperty("URN")
    public void setUrn(String urn) {
        this.urn = urn;
    }

    @JsonProperty("UTRNUMBER")
    public String getUtrnumber() {
        return utrnumber;
    }

    @JsonProperty("UTRNUMBER")
    public void setUtrnumber(String utrnumber) {
        this.utrnumber = utrnumber;
    }

    @JsonProperty("RESPONSE")
    public String getResponse() {
        return response;
    }

    @JsonProperty("RESPONSE")
    public void setResponse(String response) {
        this.response = response;
    }

}