package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Fault {

    @JsonProperty("faultstring")
    private String faultstring;
    @JsonProperty("detail")
    private Detail detail;

    /**
     * No args constructor for use in serialization
     *
     */
    public Fault() {
    }

    public Fault(String faultstring, Detail detail) {
        super();
        this.faultstring = faultstring;
        this.detail = detail;
    }

    public String getFaultstring() {
        return faultstring;
    }

    public void setFaultstring(String faultstring) {
        this.faultstring = faultstring;
    }

    public Detail getDetail() {
        return detail;
    }

    public void setDetail(Detail detail) {
        this.detail = detail;
    }

}
