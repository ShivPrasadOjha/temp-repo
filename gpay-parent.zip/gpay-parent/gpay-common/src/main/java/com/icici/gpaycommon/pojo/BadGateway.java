package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.icici.gpaycommon.dto.PaymentResponse;

/**
 * @author aditya_shekhar on 2/28/2024
 */
public class BadGateway implements PaymentResponse{

    private String fault;
    @JsonIgnore
    private int responseCode;
    @JsonIgnore
    private String responseBody;

    public String getFault() {
        return fault;
    }

    public void setFault(String fault) {
        this.fault = fault;
    }

    @Override
    public int getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    @Override
    public String getResponseBody() {
        return responseBody;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }
}
