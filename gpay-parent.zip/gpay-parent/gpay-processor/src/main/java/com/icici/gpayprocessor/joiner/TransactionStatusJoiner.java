package com.icici.gpayprocessor.joiner;

import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.enums.PAYMENT_STATUS;
import org.apache.kafka.streams.kstream.ValueJoiner;

/**
 * @author aditya_shekhar on 2/27/2024
 */
public class TransactionStatusJoiner implements ValueJoiner<Payment, Payment, Payment>{

    @Override
    public Payment apply(Payment payment1, Payment payment2) {
        Payment validPayment = null;
        if(payment1!=null && payment2==null) {
            validPayment = payment1;
        } else if(payment1==null && payment2!=null) {
            validPayment = payment2;
        } else if(payment1!=null && payment2!=null) {
            validPayment = payment2;
        }
        return validPayment;
    }

}
