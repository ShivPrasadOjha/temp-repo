package com.icici.gpayprocessor.impl;

import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.exception.ProcessorException;
import com.icici.gpaycommon.serdes.*;
import com.icici.gpaycommon.topic.KafkaTopics;
import com.icici.gpayprocessor.helper.PropertyHelper;
import com.icici.gpayprocessor.joiner.TransactionStatusJoiner;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.*;
import org.apache.kafka.streams.kstream.*;

import java.util.Properties;

/**
 * @author aditya_shekhar on 2/26/2024
 */
public class TransactionTrackingProcessor extends BaseProcessor {
    private Properties props;
    {
        props = PropertyHelper.getInstance().getProperties();
    }
    private String pmtPendingParkedTopic = KafkaTopics.GPAY_PMT_PENDING_PARKED_TOPIC;
    private String pmtCompleteTopic = KafkaTopics.GPAY_PMT_COMPLETE_TOPIC;
    private String pmtFailedTopic = KafkaTopics.GPAY_PMT_FAILED_TOPIC;
    private String pmtStatusCheckTrackerTopic = KafkaTopics.GPAY_PMT_STATUS_CHECK_TRACKER_TOPIC;
    private String pmtBlockedTopic = KafkaTopics.GPAY_PMT_BLOCKED_TOPIC;
    private String pmtTransactionTrackerTopic = KafkaTopics.GPAY_PMT_TRANSACTION_TRACKER_TOPIC; //log compaction
    private String pmtPendingTrackerTopic = KafkaTopics.GPAY_PMT_PENDING_TRACKER_TOPIC;
    private String pmtUpiPendingTopic = KafkaTopics.GPAY_PMT_UPI_PENDING_TOPIC;
    private String pmtRtgsPendingTopic = KafkaTopics.GPAY_PMT_RTGS_PENDING_TOPIC;
    private String pmtImpsPendingTopic = KafkaTopics.GPAY_PMT_IMPS_PENDING_TOPIC;
    private String pmtNeftPendingTopic = KafkaTopics.GPAY_PMT_NEFT_PENDING_TOPIC;
    private String pmtFtPendingTopic = KafkaTopics.GPAY_PMT_FT_PENDING_TOPIC;

    private String appID = props.getProperty("GPAY_TRANSACTION-TRACKER_APP_ID");
    private StreamsBuilder builder = null;

    public TransactionTrackingProcessor() throws ProcessorException {
        super();
    }

    @Override
    public Topology build(StreamsBuilder builder) {
        builder = new StreamsBuilder();
        KTable<String, Payment> pmtPendingParkedTable = builder.table(pmtPendingParkedTopic, Consumed.with(Serdes.String(),
                PaymentSerdes.serde()));
        KTable<String, Payment> pmtCompleteFinalTable = builder.table(pmtCompleteTopic, Consumed.with(Serdes.String(), PaymentSerdes.serde()));
        KTable<String, Payment> pmtFailureFinalTable = builder.table(pmtFailedTopic, Consumed.with(Serdes.String(), PaymentSerdes.serde()));

        KTable<String, Payment> pmtPendingStream = builder.table(pmtPendingTrackerTopic, Consumed.with(Serdes.String(),
                PaymentSerdes.serde()));
        KTable<String, Payment> pmtStatusCheckStream = builder.table(pmtStatusCheckTrackerTopic, Consumed.with(Serdes.String(),
                PaymentSerdes.serde()));

        ValueJoiner<Payment, Payment, Payment> transactionStatusJoiner = new TransactionStatusJoiner();

        KTable<String, Payment> paymentPrkCmpEnriched = pmtPendingParkedTable.leftJoin(pmtCompleteFinalTable, transactionStatusJoiner);
        paymentPrkCmpEnriched.toStream().peek( (k,v) -> System.out.println("paymentPrkCmpEnriched :: " + k + "--" + v.getSettlementId()
                + "--" + v.getTransactionId() + "--" + v.getPaymentStatus()));
        KTable<String, Payment> paymentPendingEnriched = pmtPendingStream.leftJoin(pmtStatusCheckStream, transactionStatusJoiner);
        paymentPendingEnriched.toStream().peek( (k,v) -> System.out.println("paymentPendingEnriched :: " + k + "--" + v.getSettlementId()
                + "--" + v.getTransactionId() + "--" + v.getPaymentStatus()));
        KTable<String, Payment> pmtPendingFinalEnriched = paymentPendingEnriched.leftJoin(paymentPrkCmpEnriched, transactionStatusJoiner);
        pmtPendingFinalEnriched.toStream().peek( (k,v) -> System.out.println("pmtPendingFinalEnriched :: " + k + "--" + v.getSettlementId()
                + "--" + v.getTransactionId() + "--" + v.getPaymentStatus()));

        KTable<String, Payment> pmtFinalEnrichedTemp = pmtPendingFinalEnriched.outerJoin(pmtCompleteFinalTable,transactionStatusJoiner);
        pmtFinalEnrichedTemp.toStream().peek( (k,v) -> System.out.println("pmtFinalEnrichedTemp :: " + k + "--" + v.getSettlementId()
                + "--" + v.getTransactionId() + "--" + v.getPaymentStatus()));
        KTable<String, Payment> pmtFinalEnriched = pmtFailureFinalTable.outerJoin(pmtFinalEnrichedTemp,transactionStatusJoiner);
        pmtFinalEnriched.toStream().peek( (k,v) -> System.out.println("pmtFinalEnriched :: " + k + "--" + v.getSettlementId()
                + "--" + v.getTransactionId() + "--" + v.getPaymentStatus()));

        /*KTable<String, Payment> pmtFinal = pmtBlockedTable.outerJoin(pmtFinalEnriched,transactionStatusJoiner);
        pmtFinal.toStream().peek( (k,v) -> System.out.println("pmtFinal :: " + k + "--" + v.getSettlementId()
                + "--" + v.getTransactionId() + "--" + v.getPaymentStatus()));*/

        KStream<String, Payment> pmtFinalEnrichedRekeyed = pmtFinalEnriched.toStream()
                .map( (key, val) -> KeyValue.pair(val.getTransactionId(), val));
        pmtFinalEnrichedRekeyed.peek( (k,v) -> System.out.println("pmtFinalEnrichedRekeyed :: " + k + "--" + v.getSettlementId()
                + "--" + v.getTransactionId() + "--" + v.getPaymentStatus()));

        KStream<String, Payment> pmtBlockedStream = builder.stream(pmtBlockedTopic, Consumed.with(Serdes.String(),
                PaymentSerdes.serde())).map( (key, val) -> KeyValue.pair(val.getTransactionId(), val));
        pmtBlockedStream.peek( (k,v) -> System.out.println("pmtBlockedStream :: " + k + "--" + v.getSettlementId()
                + "--" + v.getTransactionId() + "--" + v.getPaymentStatus()));

        pmtBlockedStream.to(pmtTransactionTrackerTopic, Produced.with(Serdes.String(), PaymentSerdes.serde()));
        pmtFinalEnrichedRekeyed.to(pmtTransactionTrackerTopic, Produced.with(Serdes.String(), PaymentSerdes.serde()));

        Topology topology = builder.build();
        return topology;
    }

    @Override
    public void run() {
        Topology topology = build(builder);
        super.streamsConfiguration.put(StreamsConfig.APPLICATION_ID_CONFIG, appID);
        KafkaStreams streams = new KafkaStreams(topology, super.streamsConfiguration);
        streams.start();
    }

    /*public static void main(String[] args) throws ProcessorException {
        System.out.println("DedupAltProcessor starting.....");
        BaseProcessor bp = new DedupAltProcessor();
        bp.run();
        System.out.println("DedupAltProcessor running now.....");
    }*/
}
