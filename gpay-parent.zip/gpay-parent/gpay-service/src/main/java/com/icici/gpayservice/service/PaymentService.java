package com.icici.gpayservice.service;

import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.dto.PaymentRetry;
import com.icici.gpaycommon.enums.PAYMENT_TYPE;
import com.icici.gpaycommon.exception.ProcessorException;
import com.icici.gpaycommon.pojo.PaymentRequestIMPS;
import com.icici.gpaycommon.pojo.PaymentRequestNEFT;
import com.icici.gpaycommon.pojo.PaymentRequestRTGS;
import com.icici.gpaycommon.pojo.PaymentRequestUPI;
import com.icici.gpaycommon.topic.KafkaTopics;
import com.icici.gpaycommon.util.DelayUtil;
import io.confluent.ksql.api.client.Row;
import org.apache.kafka.clients.producer.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * @author aditya_shekhar on 1/20/2024
 */
@Service
public class PaymentService {

    @Autowired
    private Properties brokerProps;
    private String retryTrackingTopic = KafkaTopics.GPAY_PMT_PENDING_TRACKER_TOPIC;
    private String pmtFailedTopic = KafkaTopics.GPAY_PMT_FAILED_TOPIC;
    private final RestTemplate restTemplate;

    @Autowired
    DatabaseConnectionManager databaseConnectionManager;

    public PaymentService(RestTemplateBuilder restTemplateBuilder) {
        this.restTemplate = restTemplateBuilder.build();
    }

    public List<Row> getPaymentStatus(String settlementId, String transactionId) throws ProcessorException {
        String pmtStatusQuery = "SELECT * FROM gpay_payment_status_enriched WHERE SETTLEMENTID='" + settlementId +
                "' AND TRANSACTIONID='" + transactionId + "';";
        List<Row> rows = new ArrayList<>();
        int counter = 0;
        do {
            counter++;
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new ProcessorException(e.getMessage());
            }
            rows = databaseConnectionManager.getInstance().getData(pmtStatusQuery);
        } while((rows==null || (rows!=null && rows.size()==0)) && counter<3);
        return rows;
    }

    public List<Row> getTransaction(String transactionId) throws ProcessorException {
        String pmtStatusQuery = "SELECT * FROM gpay_payment_transaction_tracker WHERE TRANSACTIONID ='" + transactionId + "';";
        List<Row> rows = new ArrayList<>();
        try {
            rows = databaseConnectionManager.getInstance().getData(pmtStatusQuery);
        } catch (ProcessorException e) {
            e.printStackTrace();
            throw new ProcessorException(e.getMessage());
        }
        return rows;
    }

    public List<Row> getDedupPayment(Payment payment) throws ProcessorException {
        String pmtStatusQuery = "SELECT * FROM gpay_payment_status_enriched WHERE SETTLEMENTID ='" + payment.getSettlementId() +
                "' AND TRANSACTIONID ='" + payment.getTransactionId() + "' AND UUID ='" + payment.getUuid() + "';";
        List<Row> rows = new ArrayList<>();
        int counter = 0;
        int lag = 4;
        do {
            counter++;
            DelayUtil delay = new DelayUtil();
            delay.delay(lag * counter, TimeUnit.SECONDS);
            try {
                rows = databaseConnectionManager.getInstance().getData(pmtStatusQuery);
            } catch (ProcessorException e) {
                e.printStackTrace();
                throw new ProcessorException(e.getMessage());
            }
        } while((rows==null || (rows!=null && rows.size()==0)) && counter<3);
        return rows;
    }

    //@Async
    /*public CompletableFuture<Payment> paymentDedupCheck(Payment paymentRequest) throws InterruptedException {
        Payment responsePmt = null;
        //LOG.info("Looking up Settlement ID: {}", paymentRequest);
        Producer<String, Payment> producer = null;
        producer = new KafkaProducer<>(brokerProps);
        try {
            producer = new KafkaProducer<String, Payment>(brokerProps);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ProducerRecord<String, Payment> record = new ProducerRecord<String, Payment>(KafkaTopics.GPAY_PMT_REQUEST_TOPIC, paymentRequest.getSettlementId(),
                paymentRequest);
        if (producer != null) {
            try {
                Future<RecordMetadata> future = producer.send(record);
                RecordMetadata metadata = future.get();
                responsePmt = paymentRequest;
                System.out.println("Producer uuid :: " + responsePmt.getUuid());
            } catch (Exception e) {
                System.err.println(e.getMessage());
                e.printStackTrace();
            }
        }
        producer.close();
        //Thread.sleep(4000L);
        return CompletableFuture.completedFuture(responsePmt);
    }

    @Async
    public CompletableFuture<Payment> updateProcessedPayment(Payment paymentResponse) throws InterruptedException {
        Payment responsePmt = null;
        Producer<String, Payment> producer = null;
        producer = new KafkaProducer<>(brokerProps);
        try {
            producer = new KafkaProducer<String, Payment>(brokerProps);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ProducerRecord<String, Payment> record = new ProducerRecord<String, Payment>(KafkaTopics.GPAY_PMT_COMPLETE_TOPIC, paymentResponse.getSettlementId(),
                paymentResponse);
        if (producer != null) {
            try {
                Future<RecordMetadata> future = producer.send(record);
                RecordMetadata metadata = future.get();
                responsePmt = paymentResponse;
            } catch (Exception e) {
                System.err.println(e.getMessage());
                e.printStackTrace();
            }
        }
        producer.close();
        return CompletableFuture.completedFuture(responsePmt);
    }

    @Async
    public CompletableFuture<Payment> updateFailedPayment(Payment paymentIp) throws InterruptedException {
        Payment paymentResponse = paymentIp;
        Payment responsePmt = null;
        Producer<String, Payment> producer = null;
        producer = new KafkaProducer<>(brokerProps);
        try {
            producer = new KafkaProducer<String, Payment>(brokerProps);
        } catch (Exception e) {
            e.printStackTrace();
        }
        PAYMENT_TYPE paymentType = paymentResponse.getPaymentType();
        ProducerRecord<String, Payment> recordFailed = new ProducerRecord<String, Payment>(pmtFailedTopic, paymentResponse.getSettlementId(), paymentResponse);
        ProducerRecord<String, Payment> record = null;
        if (producer != null) {
            try {
                Future<RecordMetadata> future = producer.send(recordFailed);
                RecordMetadata metadata = future.get();
                responsePmt = paymentResponse;
            } catch (Exception e) {
                System.err.println(e.getMessage());
                e.printStackTrace();
            }
        }
        producer.close();
        return CompletableFuture.completedFuture(responsePmt);
    }

    @Async
    public CompletableFuture<Payment> updatePendingPayment(Payment paymentIp) throws InterruptedException {
        Payment paymentResponse = paymentIp;
        PaymentRetry retry = new PaymentRetry();
        paymentResponse.setPaymentRetry(retry);
        Payment responsePmt = null;
        Producer<String, Payment> producer = null;
        producer = new KafkaProducer<>(brokerProps);
        try {
            producer = new KafkaProducer<String, Payment>(brokerProps);
        } catch (Exception e) {
            e.printStackTrace();
        }
        PAYMENT_TYPE paymentType = paymentResponse.getPaymentType();
        ProducerRecord<String, Payment> recordTracker = new ProducerRecord<String, Payment>(retryTrackingTopic, paymentResponse.getSettlementId(), paymentResponse);
        ProducerRecord<String, Payment> record = null;
        switch(paymentType) {
            case IMPS:
                record = new ProducerRecord<String, Payment>(KafkaTopics.GPAY_PMT_IMPS_PENDING_TOPIC, paymentResponse.getSettlementId(),
                        paymentResponse);
                break;
            case UPI:
                record = new ProducerRecord<String, Payment>(KafkaTopics.GPAY_PMT_UPI_PENDING_TOPIC, paymentResponse.getSettlementId(),
                        paymentResponse);
                break;
            case NEFT:
                record = new ProducerRecord<String, Payment>(KafkaTopics.GPAY_PMT_NEFT_PENDING_TOPIC, paymentResponse.getSettlementId(),
                        paymentResponse);
                break;
            case RTGS:
                record = new ProducerRecord<String, Payment>(KafkaTopics.GPAY_PMT_RTGS_PENDING_TOPIC, paymentResponse.getSettlementId(),
                        paymentResponse);
                break;
            case FT:
                record = new ProducerRecord<String, Payment>(KafkaTopics.GPAY_PMT_FT_PENDING_TOPIC, paymentResponse.getSettlementId(),
                        paymentResponse);
                break;
        }
        if (producer != null) {
            try {
                Future<RecordMetadata> future = producer.send(recordTracker);
                RecordMetadata metadata = future.get();
                producer.send(record);
                responsePmt = paymentResponse;
            } catch (Exception e) {
                System.err.println(e.getMessage());
                e.printStackTrace();
            }
        }
        producer.close();
        return CompletableFuture.completedFuture(responsePmt);
    }*/

}