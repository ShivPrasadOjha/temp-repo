package com.icici.gpayservice;

import com.fasterxml.jackson.databind.ser.std.StringSerializer;
import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.serializer.PaymentSerializer;
import io.confluent.ksql.api.client.ClientOptions;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executor;

/**
 * @author aditya_shekhar on 1/20/2024
 */
@EnableSwagger2
@SpringBootApplication
public class FrontOffice {

    @Autowired
    Environment env;

    @Value("${KSQLDB_SERVER_HOST}")
    private String ksqlHost;

    @Value("${KSQLDB_SERVER_PORT}")
    private int ksqlPort;

    @Value("${BOOTSTRAP_SERVERS}")
    private String bootstrapServer;

    public static void main(String[] args) {
        SpringApplication.run(FrontOffice.class, args);
    }

    @Bean
    public ClientOptions ksqlClientOptions() {
        ClientOptions options = ClientOptions.create().setHost(ksqlHost).setPort(ksqlPort);
        if(env.getActiveProfiles()[0].equals("uat")) {
            options.setTrustStore("/frontoffice/cp.server.truststore.jks");
            options.setTrustStorePassword("changeit");
            /*options.setKeyStore("/frontoffice/cp.server.keystore.jks");
            options.setKeyStorePassword("changeit");*/
            options.setBasicAuthCredentials("KAFKAMSUSER", "Uatenv@10");
            //options.setKeyPassword()
            options.setUseTls(true);
            options.setUseAlpn(true);
        }
        return options;
    }

    /*@Bean
    public Properties brokerProps() {
        Properties props = new Properties();
        props.put("bootstrap.servers", bootstrapServer);
        props.put("acks", "all");
        props.put("retries", 0);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, PaymentSerializer.class.getName());
        if(env.getActiveProfiles()[0].equals("uat")) {
            props.put("ssl.truststore.location", "/frontoffice/cp.server.truststore.jks");
            props.put("ssl.truststore.password" ,"changeit");
            props.put("ssl.keystore.location", "/frontoffice/cp.server.keystore.jks");
            props.put("ssl.keystore.password" ,"changeit");
            props.put("security.protocol" ,"SSL");
            props.put("ssl.client.auth" ,"required");
            props.put("ssl.enabled.protocols" ,"TLSv1.2,TLSv1.1,TLSv1");
            props.put("ssl.alpn" ,"true");
        }
        return props;
    }*/

    @Bean
    public ProducerFactory<String, Payment> producerFactory() {
        Map<String, Object> configProps = new HashMap<>();
        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServer);
        configProps.put("acks", "all");
        configProps.put("retries", 0);
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, PaymentSerializer.class.getName());
        if(env.getActiveProfiles()[0].equals("uat")) {
            configProps.put("ssl.truststore.location", "/frontoffice/cp.server.truststore.jks");
            configProps.put("ssl.truststore.password" ,"changeit");
            configProps.put("ssl.keystore.location", "/frontoffice/cp.server.keystore.jks");
            configProps.put("ssl.keystore.password" ,"changeit");
            configProps.put("security.protocol" ,"SSL");
            configProps.put("ssl.client.auth" ,"required");
            configProps.put("ssl.enabled.protocols" ,"TLSv1.2,TLSv1.1,TLSv1");
            configProps.put("ssl.alpn" ,"true");
        }
        return new DefaultKafkaProducerFactory<>(configProps);
    }

    @Bean
    public KafkaTemplate<String, Payment> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }
}
