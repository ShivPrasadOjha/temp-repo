package com.icici.gpayservice.service;

import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.dto.PaymentRetry;
import com.icici.gpaycommon.enums.PAYMENT_TYPE;
import com.icici.gpaycommon.topic.KafkaTopics;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

/**
 * @author aditya_shekhar on 3/1/2024
 */
@Service
public class ProducerService {

    @Autowired
    private KafkaTemplate<String, Payment> kafkaTemplate;

    public void sendPaymentRequest(Payment paymentRequest) throws ExecutionException, InterruptedException {
        ListenableFuture<SendResult<String, Payment>> future = kafkaTemplate.send(KafkaTopics.GPAY_PMT_REQUEST_TOPIC,
                paymentRequest.getSettlementId(), paymentRequest);
        future.completable().whenComplete((result, ex) -> {
            if (ex == null) {
                System.out.println("Sent message=[" + paymentRequest.getSettlementId() + "] with offset=["
                        + result.getRecordMetadata().offset() + "]");
            } else {
                System.out.println("Unable to send message=[" + paymentRequest.getSettlementId() + "] due to : " + ex.getMessage());
            }
        });
    }

    public void sendPaymentSuccess(Payment paymentRequest) {
        ListenableFuture<SendResult<String, Payment>> future = kafkaTemplate.send(KafkaTopics.GPAY_PMT_COMPLETE_TOPIC,
                paymentRequest.getSettlementId(), paymentRequest);
        future.completable().whenComplete((result, ex) -> {
            if (ex == null) {
                System.out.println("Sent message=[" + paymentRequest.getSettlementId() + "] with offset=["
                        + result.getRecordMetadata().offset() + "]");
            } else {
                System.out.println("Unable to send message=[" + paymentRequest.getSettlementId() + "] due to : " + ex.getMessage());
            }
        });
    }

    public void sendPaymentFailure(Payment paymentFailure) {
        /*ListenableFuture<SendResult<String, Payment>> future = kafkaTemplate.send(KafkaTopics.GPAY_PMT_FAILED_TOPIC,
                paymentFailure.getSettlementId(), paymentFailure);*/
        ListenableFuture<SendResult<String, Payment>> future = kafkaTemplate.send(KafkaTopics.GPAY_PMT_COMPLETE_TOPIC,
                paymentFailure.getSettlementId(), paymentFailure);
        future.completable().whenComplete((result, ex) -> {
            if (ex == null) {
                System.out.println("sendPaymentFailure=[" + paymentFailure.getSettlementId() + "] with offset=["
                        + result.getRecordMetadata().offset() + "]");
            } else {
                System.out.println("Unable to send message::sendPaymentFailure=[" + paymentFailure.getSettlementId() + "] due to : "
                        + ex.getMessage());
            }
        });
    }

    public void sendPaymentBlocked(Payment paymentBlocked) {
        ListenableFuture<SendResult<String, Payment>> future = kafkaTemplate.send(KafkaTopics.GPAY_PMT_BLOCKED_TOPIC,
                paymentBlocked.getSettlementId(), paymentBlocked);
        future.completable().whenComplete((result, ex) -> {
            if (ex == null) {
                System.out.println("sendPaymentBlocked=[" + paymentBlocked.getSettlementId() + "] with offset=["
                        + result.getRecordMetadata().offset() + "]");
            } else {
                System.out.println("Unable to send message::sendPaymentBlocked=[" + paymentBlocked.getSettlementId() + "] due to : "
                        + ex.getMessage());
            }
        });
    }

    public void sendPaymentDeadletter(Payment paymentWIP) {
        ListenableFuture<SendResult<String, Payment>> future = kafkaTemplate.send(KafkaTopics.GPAY_PMT_RETRY_DEADLETTER_TOPIC,
                paymentWIP.getSettlementId(), paymentWIP);
        future.completable().whenComplete((result, ex) -> {
            if (ex == null) {
                System.out.println("sendPaymentFailure=[" + paymentWIP.getSettlementId() + "] with offset=["
                        + result.getRecordMetadata().offset() + "]");
            } else {
                System.out.println("Unable to send message::sendPaymentFailure=[" + paymentWIP.getSettlementId() + "] due to : "
                        + ex.getMessage());
            }
        });
    }

    public void sendPaymentPending(Payment paymentPending) {
        Payment paymentResponse = paymentPending;
        PaymentRetry retry = new PaymentRetry();
        paymentResponse.setPaymentRetry(retry);
        ListenableFuture<SendResult<String, Payment>> futureTracker = kafkaTemplate.send(KafkaTopics.GPAY_PMT_PENDING_TRACKER_TOPIC,
                paymentResponse.getSettlementId(), paymentResponse);
        futureTracker.completable().whenComplete((result, ex) -> {
            if (ex == null) {
                System.out.println("sendPaymentPending:Tracker=[" + paymentResponse.getSettlementId() + "] with offset=["
                        + result.getRecordMetadata().offset() + "]");
            } else {
                System.out.println("Unable to send message::sendPaymentPending:Tracker=[" + paymentResponse.getSettlementId() + "] due to : "
                        + ex.getMessage());
            }
        });
    PAYMENT_TYPE paymentType = paymentResponse.getPaymentType();
    ListenableFuture<SendResult<String, Payment>> futurePending = null;
    switch(paymentType) {
        case IMPS:
            futurePending = kafkaTemplate.send(KafkaTopics.GPAY_PMT_IMPS_PENDING_TOPIC, paymentResponse.getSettlementId(), paymentResponse);
            break;
        case UPI:
            futurePending = kafkaTemplate.send(KafkaTopics.GPAY_PMT_UPI_PENDING_TOPIC, paymentResponse.getSettlementId(), paymentResponse);
            break;
        case NEFT:
            futurePending = kafkaTemplate.send(KafkaTopics.GPAY_PMT_NEFT_PENDING_TOPIC, paymentResponse.getSettlementId(), paymentResponse);
            break;
        case RTGS:
            futurePending = kafkaTemplate.send(KafkaTopics.GPAY_PMT_RTGS_PENDING_TOPIC, paymentResponse.getSettlementId(), paymentResponse);
            break;
        case FT:
            futurePending = kafkaTemplate.send(KafkaTopics.GPAY_PMT_FT_PENDING_TOPIC, paymentResponse.getSettlementId(), paymentResponse);
            break;
    }
        futurePending.completable().whenComplete((result, ex) -> {
            if (ex == null) {
                System.out.println("sendPaymentPending=[" + paymentResponse.getSettlementId() + "] with offset=["
                        + result.getRecordMetadata().offset() + "]");
            } else {
                System.out.println("Unable to send message::sendPaymentPending=[" + paymentResponse.getSettlementId() + "] due to : "
                        + ex.getMessage());
            }
        });
    }
}
