package com.icici.gpayscheduler.task;

import com.icici.gpaycommon.dto.PaymentRetry;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @author aditya_shekhar on 2/5/2024
 */
public class TaskMatrix {
    //Pending	180secs	240secs	300secs	10 mins	15 mins
    private static List<Double> upiPendingTaskCutoffInMin = new ArrayList<>();

    //Pending	180 secs	240secs	300secs	10 mins	15 mins
    private static List<Double> impsPendingTaskCutoffInMin = new ArrayList<>();

    //Debit Status Check	60 mins	90 mins	120 mins
    private static List<Double> neftPendingTaskCutoffInMin = new ArrayList<>();

    //Debit Status Check 	5min	10 mins	15mins
    private static List<Double> rtgsPendingTaskCutoffInMin = new ArrayList<>();

    //Debit Status Check 	5min	10 mins	15mins
    private static List<Double> ftPendingTaskCutoffInMin = new ArrayList<>();

    static {
        Double[] upiPendingCutoffTimes = new Double[]{3.0, 4.0, 5.0, 10.0, 15.0};
        upiPendingTaskCutoffInMin = Arrays.asList(upiPendingCutoffTimes);
        Double[] impsPendingCutoffTimes = new Double[]{3.0, 4.0, 5.0, 10.0, 15.0};
        impsPendingTaskCutoffInMin = Arrays.asList(impsPendingCutoffTimes);
        Double[] neftPendingCutoffTimes = new Double[]{60.0, 90.0,  120.0};
        neftPendingTaskCutoffInMin = Arrays.asList(neftPendingCutoffTimes);
        Double[] rtgsPendingCutoffTimes = new Double[]{5.0, 10.0, 15.0};
        rtgsPendingTaskCutoffInMin = Arrays.asList(rtgsPendingCutoffTimes);
        Double[] ftPendingCutoffTimes = new Double[]{5.0, 10.0, 15.0};
        ftPendingTaskCutoffInMin = Arrays.asList(ftPendingCutoffTimes);
    }

    public static boolean isUpiCutoffApplicable(PaymentRetry paymentRetry) {
        boolean isCutoff = false;
        Date currentDatetime = java.util.Calendar.getInstance().getTime();
        long duration = currentDatetime.getTime() - paymentRetry.getLastRetryDatetime().getTime();
        double diffInMinutes = (double)TimeUnit.MILLISECONDS.toMinutes(duration);
        if(paymentRetry==null) {
            isCutoff = false;
        } else {
            int retryCount = paymentRetry.getRetryCount();
            if(paymentRetry.getRetryCount()<upiPendingTaskCutoffInMin.size() && diffInMinutes>=upiPendingTaskCutoffInMin.get(retryCount)) {
                isCutoff = true;
            }
        }
        return isCutoff;
    }

    public static boolean isUpiTriesExhausted(PaymentRetry paymentRetry) {
        boolean isCutoff = false;
        if(paymentRetry.getRetryCount()>=upiPendingTaskCutoffInMin.size()) {
            isCutoff = true;
        }
        return isCutoff;
    }

    public static boolean isImpsTriesExhausted(PaymentRetry paymentRetry) {
        boolean isCutoff = false;
        if(paymentRetry.getRetryCount()>=impsPendingTaskCutoffInMin.size()) {
            isCutoff = true;
        }
        return isCutoff;
    }

    public static boolean isNeftTriesExhausted(PaymentRetry paymentRetry) {
        boolean isCutoff = false;
        if(paymentRetry.getRetryCount()>=neftPendingTaskCutoffInMin.size()) {
            isCutoff = true;
        }
        return isCutoff;
    }

    public static boolean isRtgsTriesExhausted(PaymentRetry paymentRetry) {
        boolean isCutoff = false;
        if(paymentRetry.getRetryCount()>=rtgsPendingTaskCutoffInMin.size()) {
            isCutoff = true;
        }
        return isCutoff;
    }

    public static boolean isFtTriesExhausted(PaymentRetry paymentRetry) {
        boolean isCutoff = false;
        if(paymentRetry.getRetryCount()>=ftPendingTaskCutoffInMin.size()) {
            isCutoff = true;
        }
        return isCutoff;
    }

    public static boolean isNeftCutoffApplicable(PaymentRetry paymentRetry) {
        boolean isCutoff = false;
        Date currentDatetime = java.util.Calendar.getInstance().getTime();
        long duration = currentDatetime.getTime() - paymentRetry.getLastRetryDatetime().getTime();
        double diffInMinutes = (double)TimeUnit.MILLISECONDS.toMinutes(duration);
        if(paymentRetry==null) {
            isCutoff = false;
        } else {
            int retryCount = paymentRetry.getRetryCount();
            if(paymentRetry.getRetryCount()<neftPendingTaskCutoffInMin.size() && diffInMinutes>=neftPendingTaskCutoffInMin.get(retryCount)) {
                isCutoff = true;
            }
        }
        return isCutoff;
    }

    public static boolean isImpsCutoffApplicable(PaymentRetry paymentRetry) {
        boolean isCutoff = false;
        Date currentDatetime = java.util.Calendar.getInstance().getTime();
        long duration = currentDatetime.getTime() - paymentRetry.getLastRetryDatetime().getTime();
        double diffInMinutes = (double)TimeUnit.MILLISECONDS.toMinutes(duration);
        if(paymentRetry==null) {
            isCutoff = false;
        } else {
            int retryCount = paymentRetry.getRetryCount();
            if(paymentRetry.getRetryCount()<impsPendingTaskCutoffInMin.size() && diffInMinutes>=impsPendingTaskCutoffInMin.get(retryCount)) {
                isCutoff = true;
            }
        }
        return isCutoff;
    }

    public static boolean isRtgsCutoffApplicable(PaymentRetry paymentRetry) {
        boolean isCutoff = false;
        Date currentDatetime = java.util.Calendar.getInstance().getTime();
        long duration = currentDatetime.getTime() - paymentRetry.getLastRetryDatetime().getTime();
        double diffInMinutes = (double)TimeUnit.MILLISECONDS.toMinutes(duration);
        if(paymentRetry==null) {
            isCutoff = false;
        } else {
            int retryCount = paymentRetry.getRetryCount();
            if(paymentRetry.getRetryCount()<rtgsPendingTaskCutoffInMin.size() && diffInMinutes>=rtgsPendingTaskCutoffInMin.get(retryCount)) {
                isCutoff = true;
            }
        }
        return isCutoff;
    }

    public static boolean isFtCutoffApplicable(PaymentRetry paymentRetry) {
        boolean isCutoff = false;
        Date currentDatetime = java.util.Calendar.getInstance().getTime();
        long duration = currentDatetime.getTime() - paymentRetry.getLastRetryDatetime().getTime();
        double diffInMinutes = (double)TimeUnit.MILLISECONDS.toMinutes(duration);
        if(paymentRetry==null) {
            isCutoff = false;
        } else {
            int retryCount = paymentRetry.getRetryCount();
            if(paymentRetry.getRetryCount()<ftPendingTaskCutoffInMin.size() && diffInMinutes>=ftPendingTaskCutoffInMin.get(retryCount)) {
                isCutoff = true;
            }
        }
        return isCutoff;
    }
}
