package com.icici.gpayscheduler.joiner;

import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.dto.PaymentReference;
import com.icici.gpaycommon.enums.PAYMENT_STATUS;
import org.apache.kafka.streams.kstream.ValueJoiner;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public class PendingPaymentstJoiner implements ValueJoiner<Payment, Payment, Payment> {

    @Override
    public Payment apply(Payment payment1, Payment payment2) {
        Payment validPayment = null;
        if(payment1!=null && payment1.getSettlementId()!=null && payment1.getTransactionId()!=null
                && payment2==null && payment1.getPaymentRetry().getRetryCount()==1) {
            validPayment = payment1;
        } else if(payment1!=null && payment1.getSettlementId()!=null && payment1.getTransactionId()!=null
                && payment2!=null && payment2.getSettlementId()!=null && payment2.getTransactionId()!=null
                && payment1.getPaymentRetry().getRetryCount()>payment2.getPaymentRetry().getRetryCount()) {
            validPayment = payment1;
        }
        return validPayment;
    }

}
